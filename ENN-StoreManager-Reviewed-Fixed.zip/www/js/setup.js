
import {
  initDatabase,
  runQuery,
  getQuery,
  executeTransaction
} from "./database.js";

const productList = document.getElementById("product-list");
const message = document.getElementById("setup-message");

let productCount = 0;

function addProductForm() {
  productCount++;

  const div = document.createElement("div");
  div.className = "product-entry";

  div.innerHTML = `
    <h3>ကုန်ပစ္စည်း #${productCount}</h3>

    <label class="setup-label">ကုန်ပစ္စည်းအမည်</label>
    <input class="setup-input product-name"
      placeholder="ဥပမာ - ဆန်တစ်အိတ်">

    <label class="setup-label">အမျိုးအစား</label>
    <input class="setup-input product-category"
      placeholder="ဥပမာ - စားသောက်ကုန်">

    <label class="setup-label">အရင်းဈေး (ကျပ်)</label>
    <input class="setup-input product-cost"
      type="number" min="0" step="0.01"
      placeholder="0">

    <label class="setup-label">ရောင်းဈေး (ကျပ်)</label>
    <input class="setup-input product-price"
      type="number" min="0" step="0.01"
      placeholder="0">

    <label class="setup-label">လက်ကျန်အရေအတွက်</label>
    <input class="setup-input product-quantity"
      type="number" min="0" step="0.01"
      placeholder="0">

    <label class="setup-label">ယူနစ်</label>
    <input class="setup-input product-unit"
      placeholder="ဥပမာ - အိတ်၊ ထုပ်၊ ခု၊ ပိဿာ">

    <label class="setup-label">အနည်းဆုံးလက်ကျန် သတိပေးအရေအတွက်</label>
    <input class="setup-input product-min"
      type="number" min="0" step="0.01"
      placeholder="5">

    <button type="button" class="setup-btn remove-product">
      ဒီကုန်ပစ္စည်းကို ဖယ်ရှားမည်
    </button>
  `;

  div.querySelector(".remove-product").addEventListener(
    "click",
    () => div.remove()
  );

  productList.appendChild(div);
}

function readNumber(element, fieldName) {
  const value = element.value.trim();

  if (value === "") {
    throw new Error(fieldName + " ထည့်သွင်းပေးပါ။");
  }

  const number = Number(value);

  if (!Number.isFinite(number) || number < 0) {
    throw new Error(fieldName + " မှန်ကန်သော ကိန်းဂဏန်းဖြစ်ရပါမယ်။");
  }

  return number;
}

async function saveSetup() {
  const shopName = document.getElementById("shop-name").value.trim();

  if (!shopName) {
    throw new Error("ဆိုင်အမည် ထည့်သွင်းပေးပါ။");
  }

  const openingCash = readNumber(
    document.getElementById("opening-cash"),
    "ဆိုင်အဖွင့်ငွေ"
  );

  const forms = [...productList.querySelectorAll(".product-entry")];

  if (forms.length === 0) {
    throw new Error("အနည်းဆုံး ကုန်ပစ္စည်းတစ်ခု ထည့်ပါ။");
  }

  const products = forms.map((form) => {
    const name = form.querySelector(".product-name").value.trim();
    const category = form.querySelector(".product-category").value.trim();
    const unit = form.querySelector(".product-unit").value.trim();

    if (!name) {
      throw new Error("ကုန်ပစ္စည်းအမည် မဖြည့်ထားပါ။");
    }

    if (!unit) {
      throw new Error(name + " ရဲ့ ယူနစ်ကို ထည့်ပါ။");
    }

    const cost = readNumber(
      form.querySelector(".product-cost"), "အရင်းဈေး"
    );

    const price = readNumber(
      form.querySelector(".product-price"), "ရောင်းဈေး"
    );

    const quantity = readNumber(
      form.querySelector(".product-quantity"), "အရေအတွက်"
    );

    const minStock = readNumber(
      form.querySelector(".product-min"), "အနည်းဆုံးလက်ကျန်"
    );

    return {
      name,
      category: category || "အထွေထွေ",
      cost,
      price,
      quantity,
      unit,
      minStock
    };
  });

  await initDatabase();

  // Prevent accidental duplicate initial setup.
  const existing = await getQuery(
    "SELECT value FROM settings WHERE key = ?",
    ["setup_completed"]
  );

  if (existing.values?.length) {
    throw new Error("ဆိုင် Setup လုပ်ပြီးသားဖြစ်ပါတယ်။ ထပ်မံ Setup မလုပ်ပါနှင့်။");
  }

  // Save setup atomically: a failure cannot leave half-created opening balances.
  await executeTransaction(async tx => {
    await tx.run(
      `INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`,
      ["shop_name", shopName]
    );
    await tx.run(
      `INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`,
      ["opening_cash", String(openingCash)]
    );
    await tx.run(
      `INSERT INTO cash_transactions (type, amount, reference_type, note)
       VALUES (?, ?, ?, ?)`,
      ["opening_balance", openingCash, "setup", "ဆိုင်စတင်အဖွင့်ငွေ"]
    );
    for (const product of products) {
      await tx.run(
        `INSERT INTO products
          (name, category, purchase_price, selling_price, quantity, unit, min_stock)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [product.name, product.category, product.cost, product.price,
         product.quantity, product.unit, product.minStock]
      );
    }
    await tx.run(
      `INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)`,
      ["setup_completed", "true"]
    );
  });

  message.className = "success-message";
  message.textContent =
    "Setup အောင်မြင်ပါပြီ။ ကုန်ပစ္စည်း " +
    products.length + " မျိုး သိမ်းဆည်းပြီးပါပြီ။";
}

document.getElementById("add-product-btn")
  .addEventListener("click", addProductForm);

document.getElementById("save-setup-btn")
  .addEventListener("click", async () => {
    const button = document.getElementById("save-setup-btn");

    button.disabled = true;
    message.textContent = "";

    try {
      await saveSetup();
    } catch (error) {
      message.className = "";
      message.style.color = "#d33";
      message.textContent = error.message;
      console.error(error);
    } finally {
      button.disabled = false;
    }
  });

// Start with one empty product form.
addProductForm();
