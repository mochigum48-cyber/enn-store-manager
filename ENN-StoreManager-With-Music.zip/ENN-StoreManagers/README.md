# ENN Store Manager

Offline grocery-shop accounting app built with Vite + Capacitor + SQLite.

## Included
- Product catalogue with pack size, pack/loose opening stock, cost and margin-based retail/wholesale price previews
- Cash, credit and partial-payment sales; stock reduction; customer debt ledger
- Debt repayments recorded as cash received (not as new sales)
- Purchases with weighted-average unit cost and cash paid tracking
- Expense recording, dashboard and daily/monthly summary
- Local SQLite database on the Android device

## Build
Requires Node.js 20+ and Android Studio/JDK configured for Capacitor.

```sh
npm install
npm run build
npx cap add android   # only the first time
npx cap sync android
npx cap open android
```

Build the APK from Android Studio. `capacitor.config.json` uses `dist` as the Vite output folder.

## Important accounting notes
- Sales revenue includes cash and credit sales; cash balance increases only by the amount actually received.
- Customer debt repayments increase cash and reduce receivables; they are not counted as sales.
- Purchases increase stock at weighted-average cost. Only the amount paid is deducted from cash.
- Unpaid supplier balances are displayed as unpaid in purchase records but a separate supplier-payables/repayment ledger is not implemented yet.
- Profit shown is an estimate from sale item cost snapshots less recorded expenses. It excludes adjustments, spoilage, owner withdrawals and other non-recorded changes.

## Current limitations
- No automatic cloud backup/sync. SQLite data is stored locally on the device; keep device backups/export separately.
- Background music is optional. Put your own licensed MP3 at `www/assets/music/background.mp3`.
- Barcode မလိုအပ်ပါ။ ကုန်ပစ္စည်းအမည်ဖြင့်သာ ရှာဖွေနိုင်သည်။
- This source archive has been statically reviewed. It must still be built and tested on an actual Android device before being used for live financial records.


## APK build and app icon
- The original `For Ma Ma♡` artwork is preserved at `www/assets/for-ma-ma-app-icon.png`.
- Android launcher icon resources are generated from that exact artwork at Android density sizes under `android-res/`.
- The Vite configuration explicitly includes all nine HTML pages. This is important: without multi-page inputs, Vite only bundles `index.html`, which can cause pages such as `sales.html` to fail with a localhost response error inside the APK.
- GitHub Actions installs dependencies without npm cache because this repository intentionally does not include a lockfile. It builds the web app, creates/syncs the Capacitor Android project, applies launcher icons, builds the debug APK, and uploads it as an Actions artifact.


## Background music (BGM)
Two supplied tracks are included:
- `www/assets/music/music1.mp3`
- `www/assets/music/music2.mp3`

The home screen has Play/Pause and Next controls. Tracks advance automatically when one ends.
To add more songs later, place them in the same folder as `music3.mp3`, `music4.mp3`, etc., then add their paths to the `playlist` array in `www/js/app.js`.
