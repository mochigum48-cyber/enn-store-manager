# ENN Store Manager — GitHub Cloud APK Build

This archive includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

## Build from a phone
1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload the **contents** of the extracted `ENN-StoreManager` folder to the repository root. Do not upload the outer folder itself. Include the `.github` folder.
4. Open the repository's **Actions** tab and enable Actions if prompted.
5. Run **Build Android APK** using **Run workflow**, or push/commit to `main`.
6. When the run completes successfully, open the run and download the `ENN-StoreManager-debug-apk` artifact. Extract it and install `app-debug.apk` on your Android phone.

The workflow builds a debug APK for testing. It is not a Play Store release-signed APK. The first build has not yet been verified on GitHub; check the Actions log if it fails.
