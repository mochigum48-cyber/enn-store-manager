# Build repair notes

## Repairs applied in this archive
- Kept the actual purchase page filename `purchase.html` consistently in Vite inputs and build verification.
- Removed the GitHub Actions step that copied Android launcher bitmap folders that are not present in this ZIP. That step would fail after the web build; Capacitor's generated default launcher resources are retained for now.
- Strengthened `scripts/verify-build.mjs` to check all nine HTML pages, both non-empty bundled music tracks, and the home navigation route configuration.
- Confirmed all local HTML `src`/`href` references in the source pages resolve.
- Confirmed JavaScript files and the build-verification script pass Node syntax checks.

## Verification limits
- A full `npm install` could not complete in the repair environment because package download timed out.
- The Vite build, Capacitor Android sync, Gradle APK build, and installation on a physical Android device have therefore **not** been run here.
- Push this source to GitHub and run the included Actions workflow. Only a successful Actions run and a device test can confirm the final APK works end-to-end.

## Important
- The two music tracks are bundled as `music1.mp3` and `music2.mp3`.
- The archive does not contain the original `For Ma Ma♡` launcher artwork as Android density icon files. This repair avoids a guaranteed workflow failure caused by copying absent icon folders; it does not claim to apply that custom launcher icon.
