/* Persistent app shell: page content swaps without destroying the audio element. */
const PAGE_ROUTES = {
  home: './index.html', dashboard: './index.html', sales: './sales.html',
  products: './products.html', debts: './debts.html', purchases: './purchase.html',
  expenses: './expenses.html', reports: './reports.html', cashbook: './cashbook.html', settings: './settings.html'
};
const shellStyle = document.createElement('style');
shellStyle.textContent = `
#enn-global-header{position:sticky;top:0;z-index:9999;background:#101827;color:#fff;padding:calc(8px + env(safe-area-inset-top)) 12px 10px;box-shadow:0 4px 18px #0003;font-family:inherit}
#enn-global-header .eh-top{display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap}
#enn-global-header .eh-brand{font-weight:800;font-size:14px;letter-spacing:.2px;white-space:nowrap}
#enn-global-header .eh-actions{display:flex;gap:7px;align-items:center;flex-wrap:wrap}
#enn-global-header button{border:1px solid #3a4c68;background:#1c2b43;color:#fff;border-radius:10px;padding:9px 12px;font-size:13px;min-height:40px;white-space:nowrap}
#enn-global-header button:disabled{opacity:.4}
#enn-global-header .eh-music{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
#enn-global-header .eh-track{font-size:11px;color:#c8d4e8;max-width:82px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#enn-global-header .eh-music button{min-height:36px;padding:7px 9px}
@media(max-width:430px){#enn-global-header .eh-top{align-items:flex-start}#enn-global-header .eh-brand{width:100%;padding:2px 2px 4px}#enn-global-header .eh-actions{width:100%;order:2}#enn-global-header .eh-music{width:100%}#enn-global-header .eh-track{max-width:100px}}
#enn-bottom-actions{position:fixed;left:50%;transform:translateX(-50%);bottom:74px;width:min(780px,100%);z-index:10000;display:flex;gap:10px;padding:9px 12px;background:#fff;border-top:1px solid #e9edf3;box-shadow:0 -4px 16px #0000000d}
#enn-bottom-actions button{flex:1;min-height:42px;border:1px solid #d9e0e9;border-radius:11px;background:#f1f4f8;color:#26364f;font-size:14px;font-weight:800}
#enn-bottom-actions #enn-home{background:#29466c;border-color:#29466c;color:#fff}
body{padding-top:0!important;padding-bottom:132px!important}
`;
document.head.appendChild(shellStyle);
document.documentElement.dataset.theme=localStorage.getItem('ennDarkMode')==='1'?'dark':'light';
let header = document.getElementById('enn-global-header');
if (!header) {
  header = document.createElement('header'); header.id='enn-global-header';
  header.innerHTML = `<div class="eh-top"><div class="eh-brand">ENN STORE MANAGER</div><div class="eh-actions"><div class="eh-music"><span class="eh-track" id="enn-track">music1</span><button id="enn-play" type="button">♫ Play</button><button id="enn-next" type="button">⏭ Next</button><button id="enn-add-music" type="button">＋ Add Music</button><input id="enn-music-file" type="file" accept="audio/*,.mp3,.m4a,.wav,.ogg" multiple hidden></div></div></div>`;
  document.body.prepend(header);
}
let bottomActions=document.getElementById('enn-bottom-actions');
if(!bottomActions){bottomActions=document.createElement('div');bottomActions.id='enn-bottom-actions';bottomActions.innerHTML='<button id="enn-back" type="button">← Back</button><button id="enn-home" type="button">⌂ Dashboard</button>';document.body.append(bottomActions);}

let audio = document.getElementById('enn-persistent-audio');
if (!audio) { audio=document.createElement('audio'); audio.id='enn-persistent-audio'; audio.preload='auto'; audio.loop=false; audio.style.display='none'; document.body.append(audio); }
let playlist=['./assets/music/music1.mp3','./assets/music/music2.mp3'];
let customTracks=[];
let track=Math.max(0,Number(localStorage.getItem('ennMusicTrack')||0));
let wantedPlay=localStorage.getItem('ennMusicPlaying')==='1';
const musicDbRequest=indexedDB.open('enn-store-manager-media',1);
musicDbRequest.onupgradeneeded=()=>musicDbRequest.result.createObjectStore('music',{keyPath:'id',autoIncrement:true});
function getMusicDB(){return new Promise((resolve,reject)=>{musicDbRequest.onsuccess=()=>resolve(musicDbRequest.result);musicDbRequest.onerror=()=>reject(musicDbRequest.error);});}
async function loadCustomMusic(){try{const d=await getMusicDB();const rows=await new Promise((resolve,reject)=>{const r=d.transaction('music').objectStore('music').getAll();r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});customTracks=rows.map((x,i)=>({name:`music${i+3}`,url:URL.createObjectURL(x.blob)}));playlist=['./assets/music/music1.mp3','./assets/music/music2.mp3',...customTracks.map(x=>x.url)];if(track>=playlist.length)track=0;audio.src=playlist[track];paintMusic();if(wantedPlay)play();}catch(e){console.warn('Custom music storage unavailable',e);}}
loadCustomMusic();
if (!audio.src) { audio.src=playlist[track]; }
function paintMusic(){const b=document.getElementById('enn-play');const t=document.getElementById('enn-track');if(b)b.textContent=audio.paused?'♫ Play':'♫ Pause';if(t)t.textContent=track<2?`music${track+1}`:(customTracks[track-2]?.name||`music${track+1}`);}
async function play(){try{await audio.play();wantedPlay=true;localStorage.setItem('ennMusicPlaying','1');}catch(e){wantedPlay=false;localStorage.setItem('ennMusicPlaying','0');console.warn('Music playback needs a user tap:',e);}paintMusic();}
document.getElementById('enn-play')?.addEventListener('click',()=>audio.paused?play():(audio.pause(),wantedPlay=false,localStorage.setItem('ennMusicPlaying','0'),paintMusic()));
document.getElementById('enn-next')?.addEventListener('click',async()=>{track=(track+1)%playlist.length;localStorage.setItem('ennMusicTrack',String(track));audio.src=playlist[track];await play();});
audio.addEventListener('ended',async()=>{track=(track+1)%playlist.length;localStorage.setItem('ennMusicTrack',String(track));audio.src=playlist[track];if(wantedPlay)await play();});
audio.addEventListener('play',paintMusic);audio.addEventListener('pause',paintMusic);paintMusic();
document.getElementById('enn-add-music')?.addEventListener('click',()=>document.getElementById('enn-music-file')?.click());
document.getElementById('enn-music-file')?.addEventListener('change',async e=>{try{const d=await getMusicDB();for(const file of [...e.target.files]){if(!file.type.startsWith('audio/')&&!/\.(mp3|m4a|wav|ogg)$/i.test(file.name))continue;await new Promise((resolve,reject)=>{const tx=d.transaction('music','readwrite');tx.objectStore('music').add({name:file.name,blob:file,addedAt:new Date().toISOString()});tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);});}await loadCustomMusic();if(customTracks.length){track=playlist.length-1;audio.src=playlist[track];document.getElementById('enn-track').textContent=customTracks[customTracks.length-1].name;await play();}alert('သီချင်းအသစ် ထည့်ပြီးပါပြီ။');}catch(err){alert('သီချင်းထည့်မရပါ: '+err.message);}e.target.value='';});
const currentPath=()=>location.pathname.split('/').pop()||'index.html';
const routeUrl=key=>new URL(PAGE_ROUTES[key]||key,location.href).href;
let ennStack=[location.href];
async function navigate(url,{push=true}={}){
  const target=new URL(url,location.href); if(target.origin!==location.origin)return;
  if(target.pathname===location.pathname && target.search===location.search)return;
  try{
    const response=await fetch(target.href); if(!response.ok)throw new Error(`Page load failed (${response.status})`);
    const html=await response.text(); const parsed=new DOMParser().parseFromString(html,'text/html');
    const nextMain=parsed.querySelector('main'); if(!nextMain)throw new Error('Target page has no main content');
    const oldMain=document.querySelector('main'); if(oldMain)oldMain.replaceWith(nextMain); else document.body.append(nextMain);
    document.title=parsed.title||'ENN Store Manager';
    document.querySelectorAll('[data-enn-page-style]').forEach(e=>e.remove());
    parsed.head.querySelectorAll('style').forEach(s=>{const c=document.createElement('style');c.dataset.ennPageStyle='1';c.textContent=s.textContent;document.head.append(c);});
    // Keep app-level stylesheet and persistent header/audio. Remove stale page-only nav/footer.
    document.querySelectorAll('.bottom-nav').forEach(e=>e.remove());
    const nav=parsed.querySelector('.bottom-nav');if(nav)document.body.append(nav.cloneNode(true));
    if(push){ennStack.push(target.href);history.pushState({enn:true,ennUrl:target.href},'',target.href);}
    const scripts=[...parsed.querySelectorAll('script[type="module"][src]')].map(s=>new URL(s.getAttribute('src'),target).href);
    for(const src of scripts){if(src.includes('/js/shell.js'))continue;await import(src+ (src.includes('?')?'&':'?')+'ennview='+Date.now());}
    window.scrollTo(0,0);paintMusic();
  }catch(error){console.error(error);alert('စာမျက်နှာဖွင့်မရပါ။ '+error.message);}
}
document.addEventListener('click',event=>{
  const pageButton=event.target.closest('[data-page]');
  if(pageButton){const key=pageButton.dataset.page;event.preventDefault();event.stopImmediatePropagation();navigate(routeUrl(key));return;}
  const link=event.target.closest('a[href]');
  if(link){const href=link.getAttribute('href');if(href&&href.startsWith('./')&&href.endsWith('.html')){event.preventDefault();event.stopImmediatePropagation();navigate(new URL(href,location.href).href);}}
},true);
document.getElementById('enn-home')?.addEventListener('click',()=>navigate(routeUrl('home')));
document.getElementById('enn-back')?.addEventListener('click',()=>{if(ennStack.length>1){ennStack.pop();navigate(ennStack[ennStack.length-1],{push:false});}else if(currentPath()!=='index.html'&&currentPath()!=='dashboard.html'){navigate(routeUrl('home'),{push:false});}else{window.scrollTo({top:0,behavior:'smooth'});}});
window.addEventListener('popstate',event=>{if(ennStack.length>1)ennStack.pop();const target=event.state?.ennUrl||location.href;navigate(target,{push:false});});
// Resume only if the user previously started playback; browsers may still require a fresh gesture.
if(wantedPlay && audio.paused) play();

// Global PIN gate: remains active across all internal page navigation.
if(!sessionStorage.getItem('ennUnlocked') && localStorage.getItem('ennAppPin')){
 const gate=document.createElement('div');gate.id='enn-pin-gate';gate.style='position:fixed;inset:0;background:#101827;z-index:30000;display:grid;place-items:center;padding:24px;color:#172235';
 gate.innerHTML='<section style="width:100%;max-width:340px;background:#fff;padding:24px;border-radius:18px"><h2>ENN Store Manager</h2><p>App PIN ထည့်ပါ</p><input id="enn-gate-pin" type="password" inputmode="numeric" placeholder="PIN"><button id="enn-gate-unlock" style="width:100%;padding:14px;margin-top:12px">ဖွင့်မယ်</button><p id="enn-gate-error"></p></section>';document.body.append(gate);
 gate.querySelector('#enn-gate-unlock').onclick=async()=>{const pin=gate.querySelector('#enn-gate-pin').value;const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(pin));const hash=Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('');if(hash===localStorage.getItem('ennAppPin')){sessionStorage.setItem('ennUnlocked','1');gate.remove();}else gate.querySelector('#enn-gate-error').textContent='PIN မှားနေပါတယ်။';};
}

// Native Android hardware Back button: step back through the in-app page history.
import('@capacitor/app').then(({App})=>{App.addListener('backButton',()=>{if(ennStack.length>1)document.getElementById('enn-back')?.click();else if(currentPath()!=='index.html'&&currentPath()!=='dashboard.html')navigate(routeUrl('home'),{push:false});else App.exitApp();});}).catch(()=>{});
