# Latest build fix

- Added the missing root-level `android-res/` launcher resource folder.
- Included all launcher icon densities and adaptive icon XML resources.
- Updated `.github/workflows/android-apk.yml` to apply icons after `npx cap sync android`.
- Kept both `purchase.html` and `purchases.html` build outputs to preserve compatibility with existing routes and verification.
