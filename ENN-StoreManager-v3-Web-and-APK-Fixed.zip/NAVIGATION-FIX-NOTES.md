ENN Store Manager v3 navigation fix

- Back and Dashboard controls are placed at the TOP of every page in the persistent app header.
- On narrow phone screens, Back and Dashboard become full-width side-by-side buttons directly under the app title.
- Back uses the app's own page stack instead of blindly calling browser history.back(), preventing accidental exit from the WebView.
- Android hardware Back is routed through the same in-app Back behavior; at the Dashboard root it exits the app.
- Music controls remain in the persistent header.

Build notes:
- Upload the CONTENTS of this ZIP to the GitHub repository root (do not upload the ZIP as a single file).
- Run the GitHub Actions workflow to create the Android APK.
- Do not open www/*.html directly in a file manager/browser for testing. SQLite imports require Vite bundling and the Capacitor Android runtime.
- JavaScript syntax checks passed for shell.js, database.js, sales.js and purchases.js.
- A full Vite/Android build was not verified in this environment because npm dependency installation timed out.
