# Build and verification status

This source archive includes a compatibility alias for the purchase page:
- `purchase.html` remains the original page used by existing navigation.
- `purchases.html` is also built as an alias so CI checks/references using the plural filename succeed.

The GitHub Actions workflow checks both page names and both bundled music tracks.

The archive is source code, not an APK. A successful GitHub Actions run is still required to produce the debug APK. The APK has not been installed or tested on a physical Android phone in this environment.

Music files are bundled as `www/public/assets/music/music1.mp3` and `music2.mp3`; Vite copies them into `dist/assets/music/`.
