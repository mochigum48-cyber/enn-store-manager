# ENN Store Manager Blueprint

## Product direction
- Brand: ENN Store Manager
- Platform: Android APK
- Stack: React Native + Expo SDK 54, SQLite local-first
- UI: pink/lavender premium style, responsive phone-first layout
- No QR and no barcode features
- Music playlist retains supplied tracks and supports local audio import

## Modules
1. Dashboard: daily sales, estimated profit, cash balance, debt receivable, inventory valuation and low-stock list.
2. Products: product name, category, unit, purchase cost, retail price, wholesale price, stock and low-stock threshold.
3. Customers: neighborhood customer profiles; phone optional.
4. Debt: separate debt/payment ledger rows; multiple borrowings and repayments; due date per debt entry; edit latest due date; overdue calculation/report planned.
5. Sales: stock deduction; full/partial/cash/credit collection; customer required when there is an unpaid balance.
6. Purchases: stock increase and weighted average purchase cost; partial supplier payment.
7. Expenses: expense entry and cash-out posting.
8. Cashbook: manual income/expense plus automatic postings for sales, purchases, expenses and debt repayment.
9. Reports: summary, printable report and XLSX export.
10. Backup: JSON export and restore.
11. Music: bundled tracks, phone audio import, persistent playlist metadata, playback controls.
12. Settings: dark theme and PIN lock.

## Accounting model
- Sales are revenue; collected amount is cash-in.
- Unpaid sale balance is customer receivable/debt.
- Repayment is cash-in and receivable reduction, not a second sale.
- Purchases increase inventory; cash-out is only the paid amount.
- Expenses reduce cash and profit.
- Opening cash is a balance entry, never revenue.
- Inventory cost uses weighted-average purchase cost.

## Database tables
- products
- customers
- sales
- purchases
- debt_entries
- cashbook
- expenses
- settings

## Next production phases
- Audit-safe edit/void with automatic reversal and reposting for sales, purchases, debt and cashbook.
- Per-debt due-date editor and overdue reminders.
- Supplier payable records.
- Firebase authentication, encrypted sync and conflict resolution (requires project credentials).
- Bluetooth printer module tested against the actual printer model.
- Android foreground media playback service and notification controls.
- Device testing, migration and backup/restore acceptance tests.
