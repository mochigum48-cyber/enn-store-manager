
import {
  initDatabase,
  getQuery,
  executeTransaction
} from "./database.js";

const $ = id => document.getElementById(id);

let customers = [];

const money = value =>
  Math.round(Number(value || 0)).toLocaleString("en-US") + " Ks";

function showMessage(text, error = false) {
  $("message").textContent = text;
  $("message").style.color = error ? "#ff7777" : "#65d9a0";
}

async function loadCustomers() {
  const result = await getQuery(`
    SELECT
      c.id,
      c.name,
      c.phone,
      COALESCE(SUM(
        CASE
          WHEN d.type = 'charge' THEN d.amount
          WHEN d.type = 'payment' THEN -d.amount
          ELSE 0
        END
      ), 0) AS balance
    FROM customers c
    LEFT JOIN debt_transactions d ON d.customer_id = c.id
    GROUP BY c.id, c.name, c.phone
    ORDER BY c.name COLLATE NOCASE
  `);

  customers = result.values || [];
  renderCustomers(customers);
  renderCustomerOptions();
}

function renderCustomerOptions() {
  const select = $("customer-select");
  const previous = select.value;

  select.replaceChildren();

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "အကြွေးယူသူရွေးပါ";
  select.appendChild(placeholder);

  customers
    .filter(customer => Number(customer.balance) > 0)
    .forEach(customer => {
      const option = document.createElement("option");
      option.value = customer.id;
      option.textContent =
        `${customer.name} — ${money(customer.balance)}`;
      select.appendChild(option);
    });

  if ([...select.options].some(option => option.value === previous)) {
    select.value = previous;
  }
}

async function loadHistory(customerId, container) {
  const result = await getQuery(
    `SELECT type, amount, note, created_at
     FROM debt_transactions
     WHERE customer_id = ?
     ORDER BY id DESC
     LIMIT 10`,
    [customerId]
  );

  const history = document.createElement("div");
  history.className = "history";

  const heading = document.createElement("strong");
  heading.textContent = "နောက်ဆုံးမှတ်တမ်းများ";
  history.appendChild(heading);

  if (!result.values?.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "အကြွေးမှတ်တမ်း မရှိသေးပါ။";
    history.appendChild(empty);
  } else {
    result.values.forEach(item => {
      const row = document.createElement("div");
      row.className = "history-row";

      const left = document.createElement("span");
      left.textContent =
        `${item.type === "charge" ? "အကြွေးတင်" : "အကြွေးဆပ်"} • ` +
        (item.note || "");

      const right = document.createElement("strong");
      right.className =
        item.type === "payment" ? "positive" : "negative";

      right.textContent =
        (item.type === "payment" ? "+" : "-") + money(item.amount);

      row.append(left, right);
      history.appendChild(row);
    });
  }

  container.appendChild(history);
}

async function renderCustomers(items) {
  const container = $("customer-list");
  container.replaceChildren();

  if (!items.length) {
    container.textContent = "အကြွေးယူသူ မရှိသေးပါ။";
    return;
  }

  for (const customer of items) {
    const card = document.createElement("article");
    card.className = "customer-card";

    const top = document.createElement("div");
    top.className = "customer-top";

    const info = document.createElement("div");

    const name = document.createElement("strong");
    name.textContent = customer.name;

    const phone = document.createElement("div");
    phone.className = "muted";
    phone.textContent = customer.phone || "ဖုန်းနံပါတ် မရှိပါ";

    info.append(name, phone);

    const balance = document.createElement("div");
    balance.className = "balance";
    balance.textContent = money(customer.balance);

    top.append(info, balance);
    card.appendChild(top);

    const status = document.createElement("p");
    status.className = "muted";
    status.textContent =
      Number(customer.balance) > 0
        ? "ကျန်ရှိနေသော အကြွေး"
        : "အကြွေးကျေပြီး";

    card.appendChild(status);

    await loadHistory(customer.id, card);

    container.appendChild(card);
  }
}

$("search").addEventListener("input", event => {
  const keyword = event.target.value.trim().toLowerCase();

  renderCustomers(customers.filter(customer =>
    (customer.name || "").toLowerCase().includes(keyword) ||
    (customer.phone || "").toLowerCase().includes(keyword)
  ));
});

$("save-payment").addEventListener("click", async () => {
  const button = $("save-payment");
  button.disabled = true;

  try {
    const customerId = Number($("customer-select").value);
    const amount = Number($("payment-amount").value);
    const note = $("payment-note").value.trim();

    if (!customerId) {
      throw new Error("အကြွေးယူသူကို ရွေးပေးပါ။");
    }

    if (!Number.isFinite(amount) || amount <= 0) {
      throw new Error("ဆပ်ငွေကို မှန်ကန်စွာ ထည့်ပါ။");
    }

    await executeTransaction(async tx => {
      const customerResult = await tx.query(
        "SELECT id FROM customers WHERE id = ?",
        [customerId]
      );

      if (!customerResult.values?.length) {
        throw new Error("အကြွေးယူသူကို ရှာမတွေ့ပါ။");
      }

      const balanceResult = await tx.query(
        `SELECT COALESCE(SUM(
          CASE
            WHEN type = 'charge' THEN amount
            WHEN type = 'payment' THEN -amount
            ELSE 0
          END
        ), 0) AS balance
        FROM debt_transactions
        WHERE customer_id = ?`,
        [customerId]
      );

      const balance = Number(balanceResult.values?.[0]?.balance || 0);

      if (balance <= 0) {
        throw new Error("ဒီအကြွေးယူသူမှာ ကျန်အကြွေး မရှိပါ။");
      }

      if (amount > balance) {
        throw new Error(
          `ကျန်အကြွေး ${money(balance)} သာရှိပါတယ်။`
        );
      }

      await tx.run(
        `INSERT INTO debt_transactions
          (customer_id, type, amount, note)
         VALUES (?, 'payment', ?, ?)`,
        [customerId, amount, note || "အကြွေးပြန်ဆပ်ငွေ"]
      );

      await tx.run(
        `INSERT INTO cash_transactions
          (type, amount, reference_type, reference_id, note)
         VALUES ('debt_payment', ?, 'customer', ?, ?)`,
        [amount, customerId, "အကြွေးပြန်ဆပ်ငွေ"]
      );
    });

    $("payment-amount").value = "";
    $("payment-note").value = "";

    showMessage("အကြွေးဆပ်ငွေ သိမ်းဆည်းပြီးပါပြီ။");
    await loadCustomers();

  } catch (error) {
    console.error(error);
    showMessage(error.message || "သိမ်းဆည်းမှု မအောင်မြင်ပါ။", true);
  } finally {
    button.disabled = false;
  }
});

async function start() {
  try {
    await initDatabase();
    await loadCustomers();
  } catch (error) {
    console.error(error);
    showMessage(
      "Database ချိတ်ဆက်မှု မအောင်မြင်ပါ။ " + error.message,
      true
    );
  }
}

start();
