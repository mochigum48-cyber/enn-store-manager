# SQLite module resolution fix

The SQLite package import is a bare npm specifier and must be bundled by Vite.
Do not open `www/index.html` directly from a file manager/browser. The Android app
must load the built `dist/` directory (`capacitor.config.json` uses `webDir: dist`).

Changes in this package:
- `npm run build` runs the strengthened `scripts/verify-build.mjs`.
- The verifier checks every page's module entry points to Vite output in `dist/assets/`.
- It rejects page HTML that still points to raw `www/js/*.js` source modules.
- It checks that SQLite and Capacitor App bare imports are absent from the final JS bundles.
- Capacitor remains configured to package `dist/`.

Build on GitHub Actions after uploading the extracted ZIP contents to the repository root.
If the error is seen while opening `www/index.html` directly, that is not a valid production
test. Test the generated APK or Vite preview of `dist/`.
