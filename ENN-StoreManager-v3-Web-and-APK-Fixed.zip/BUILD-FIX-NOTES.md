# Latest build fix

- Added the missing root-level `android-res/` launcher resource folder.
- Included all launcher icon densities and adaptive icon XML resources.
- Updated `.github/workflows/android-apk.yml` to apply icons after `npx cap sync android`.
- Kept both `purchase.html` and `purchases.html` build outputs to preserve compatibility with existing routes and verification.

## v3 changes (2026-11-16)
- Added shared app shell with persistent header controls, Dashboard shortcut, Back navigation, and page-content swapping so audio is not destroyed during in-app navigation.
- Added customer registration fields (name, phone, address) to the debts page and included address in customer search/list display.
- Replaced the invalid SQLite `getConnection()` call with the Capacitor Community SQLite connection-check/retrieve/create flow.
- Updated build verification to check the shared navigation/music bundle.
- Preserved the v2 source archive separately; this is a new v3 package.

Note: JavaScript syntax checks passed in this workspace. Full Vite/Android APK build was not completed here because dependency installation did not finish; run GitHub Actions to verify the Android build.
