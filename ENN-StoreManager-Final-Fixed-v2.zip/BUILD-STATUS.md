# Build status and latest repair

The previous GitHub Actions run stopped because the repository did not contain the `android-res/` launcher icon resource folder.

This package now includes the complete `android-res/` directory at the repository root, including launcher icon PNGs for mdpi, hdpi, xhdpi, xxhdpi and xxxhdpi, adaptive icon XML files, and the launcher background resource. The Android workflow now copies these resources into `android/app/src/main/res` after Capacitor sync and before Gradle builds the APK.

The web build previously passed its required page/music verification. This package has not yet been proven by a successful GitHub Actions Android build; upload the extracted contents to the repository root and check the next Actions run.
