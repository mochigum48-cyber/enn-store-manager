# ENN Store Manager

Offline grocery-shop accounting app built with Vite + Capacitor + SQLite.

## Included
- Product catalogue with pack size, pack/loose opening stock, cost and margin-based retail/wholesale price previews
- Cash, credit and partial-payment sales; stock reduction; customer debt ledger
- Debt repayments recorded as cash received (not as new sales)
- Purchases with weighted-average unit cost and cash paid tracking
- Expense recording, dashboard and daily/monthly summary
- Local SQLite database on the Android device

## Build
Requires Node.js 20+ and Android Studio/JDK configured for Capacitor.

```sh
npm install
npm run build
npx cap add android   # only the first time
npx cap sync android
npx cap open android
```

Build the APK from Android Studio. `capacitor.config.json` uses `dist` as the Vite output folder.

## Important accounting notes
- Sales revenue includes cash and credit sales; cash balance increases only by the amount actually received.
- Customer debt repayments increase cash and reduce receivables; they are not counted as sales.
- Purchases increase stock at weighted-average cost. Only the amount paid is deducted from cash.
- Unpaid supplier balances are displayed as unpaid in purchase records but a separate supplier-payables/repayment ledger is not implemented yet.
- Profit shown is an estimate from sale item cost snapshots less recorded expenses. It excludes adjustments, spoilage, owner withdrawals and other non-recorded changes.

## Current limitations
- No automatic cloud backup/sync. SQLite data is stored locally on the device; keep device backups/export separately.
- Background music is optional. Put your own licensed MP3 at `www/assets/music/background.mp3`.
- Barcode မလိုအပ်ပါ။ ကုန်ပစ္စည်းအမည်ဖြင့်သာ ရှာဖွေနိုင်သည်။
- This repaired source archive has JavaScript syntax checks and build-output verification configured. It still needs a fresh GitHub Actions build and an on-device test before being used for live financial records.


## APK build and app icon
- The source archive does not contain the original `For Ma Ma♡` artwork as a launcher bitmap, so the GitHub workflow keeps the standard Capacitor launcher icon rather than copying missing image folders.
- The Vite configuration explicitly includes all nine HTML pages. The build runs a verification script that fails if any required page, either music track, or a home navigation link is missing from `dist/`.
- GitHub Actions installs dependencies without npm cache because this repository intentionally does not include a lockfile. It builds the web app, creates/syncs the Capacitor Android project, applies launcher icons, builds the debug APK, and uploads it as an Actions artifact.


## Background music (BGM)
Two supplied tracks are included:
- `www/assets/music/music1.mp3`
- `www/assets/music/music2.mp3`

The home screen has Play/Pause and Next controls. Tracks advance automatically when one ends.
To add more songs later, place them in the same folder as `music3.mp3`, `music4.mp3`, etc., then add their paths to the `playlist` array in `www/js/app.js`.

## v3 additions
- Persistent header player with local MP3/audio file import (stored in IndexedDB), next/play controls.
- Cashbook manual cash-in/cash-out page.
- Settings: dark mode, PIN gate, JSON backup/restore and sales CSV export.
- Customer debt list includes name, phone, address and payment history.
- Product barcode database column migration.
- Dashboard quick links to cashbook and settings.

Note: Custom audio files and PIN are stored locally on the device/browser profile. Keep separate JSON backups. CSV export currently exports sales headers; it is not a full Excel workbook.


## Important v3 limitations
- Historical sales/purchase correction is performed by canceling with stock/cash/debt reversal, then re-entering; in-place editing is not included yet.
- CSV export currently contains sales summary columns only (Excel-compatible CSV, not a formatted XLSX workbook).
- Full Android build must be confirmed by a successful GitHub Actions run; this workspace could not install npm dependencies due timeout.
