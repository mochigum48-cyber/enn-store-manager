# SQLite Browser/APK build fix

GitHub Actions reported that `applyPolyfills` is not exported by the pinned `jeep-sqlite/loader` package (jeep-sqlite 2.8.0).

The database module now imports only `defineCustomElements` from `jeep-sqlite/loader` and no longer calls `applyPolyfills`. Modern supported browsers / Android WebView provide Custom Elements APIs. The native Android path continues to use `@capacitor-community/sqlite`; the browser path initializes the jeep-sqlite web store.

The build verifier now rejects reintroduction of the unsupported `applyPolyfills` symbol.

Build with `npm install` then `npm run build`. This source ZIP has had its JavaScript syntax and archive contents checked locally; a complete npm/Vite/Gradle build could not be completed in this environment because dependency installation timed out.
