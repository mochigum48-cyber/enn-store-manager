import { defineConfig } from 'vite';
import { resolve } from 'node:path';

const pages = [
  'index.html', 'dashboard.html', 'setup.html', 'products.html',
  'sales.html', 'purchase.html', 'purchases.html', 'debts.html', 'expenses.html', 'reports.html', 'cashbook.html', 'settings.html'
];

export default defineConfig({
  root: resolve(process.cwd(), 'www'),
  base: './',
  build: {
    outDir: resolve(process.cwd(), 'dist'),
    emptyOutDir: true,
    assetsDir: 'assets',
    rollupOptions: {
      input: Object.fromEntries(
        pages.map((page) => [
          page.replace(/\.html$/, ''),
          resolve(process.cwd(), 'www', page)
        ])
      )
    }
  }
});
