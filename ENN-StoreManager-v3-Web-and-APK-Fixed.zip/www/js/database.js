
import { Capacitor } from "@capacitor/core";
import {
  SQLiteConnection,
  CapacitorSQLite
} from "@capacitor-community/sqlite";
import {
  defineCustomElements as defineJeepSqlite,
  applyPolyfills
} from "jeep-sqlite/loader";

const sqlite = new SQLiteConnection(CapacitorSQLite);
let webStoreReady = false;

async function ensureSQLitePlatform() {
  if (Capacitor.getPlatform() !== "web" || webStoreReady) return;

  // The Web implementation of capacitor-community/sqlite requires jeep-sqlite.
  // This runs only in a real browser; Android continues to use the native plugin.
  await applyPolyfills();
  defineJeepSqlite(window);

  if (!document.querySelector("jeep-sqlite")) {
    const element = document.createElement("jeep-sqlite");
    element.setAttribute("wasm-path", `${import.meta.env.BASE_URL}assets`);
    element.style.display = "none";
    document.body.appendChild(element);
  }

  await customElements.whenDefined("jeep-sqlite");
  await sqlite.initWebStore();
  webStoreReady = true;
}
const DATABASE_NAME = "grocery_store";

let db = null;
let initializing = null;

const schema = [
  `CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  )`,

  `CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    barcode TEXT DEFAULT '',
    category TEXT DEFAULT 'အထွေထွေ',
    purchase_price REAL NOT NULL DEFAULT 0,
    selling_price REAL NOT NULL DEFAULT 0,
    quantity REAL NOT NULL DEFAULT 0,
    unit TEXT DEFAULT 'ခု',
    min_stock REAL DEFAULT 0,
    pack_name TEXT DEFAULT 'Pack',
    pack_size REAL DEFAULT 1,
    pack_purchase_price REAL DEFAULT 0,
    retail_margin_pct REAL DEFAULT 15,
    wholesale_margin_pct REAL DEFAULT 10,
    wholesale_price REAL DEFAULT 0,
    wholesale_min_qty REAL DEFAULT 1,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    address TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER,
    total REAL NOT NULL DEFAULT 0,
    paid REAL NOT NULL DEFAULT 0,
    debt REAL NOT NULL DEFAULT 0,
    payment_type TEXT NOT NULL DEFAULT 'cash',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(customer_id) REFERENCES customers(id)
  )`,

  `CREATE TABLE IF NOT EXISTS sale_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity REAL NOT NULL,
    price REAL NOT NULL,
    cost_price REAL NOT NULL,
    subtotal REAL NOT NULL,
    FOREIGN KEY(sale_id) REFERENCES sales(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
  )`,

  `CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier_name TEXT DEFAULT '',
    total REAL NOT NULL DEFAULT 0,
    paid REAL NOT NULL DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS purchase_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    purchase_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity REAL NOT NULL,
    cost_price REAL NOT NULL,
    subtotal REAL NOT NULL,
    FOREIGN KEY(purchase_id) REFERENCES purchases(id),
    FOREIGN KEY(product_id) REFERENCES products(id)
  )`,

  `CREATE TABLE IF NOT EXISTS debt_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    sale_id INTEGER,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(customer_id) REFERENCES customers(id),
    FOREIGN KEY(sale_id) REFERENCES sales(id)
  )`,

  `CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT NOT NULL,
    amount REAL NOT NULL,
    note TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`,

  `CREATE TABLE IF NOT EXISTS cash_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    amount REAL NOT NULL,
    reference_type TEXT DEFAULT '',
    reference_id INTEGER,
    note TEXT DEFAULT '',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  )`
];

const productColumns = [
  ["barcode", "TEXT DEFAULT ''"],
  ["pack_name", "TEXT DEFAULT 'Pack'"],
  ["pack_size", "REAL DEFAULT 1"],
  ["pack_purchase_price", "REAL DEFAULT 0"],
  ["retail_margin_pct", "REAL DEFAULT 15"],
  ["wholesale_margin_pct", "REAL DEFAULT 10"],
  ["wholesale_price", "REAL DEFAULT 0"],
  ["wholesale_min_qty", "REAL DEFAULT 1"]
];

async function migrateProducts() {
  const result = await db.query("PRAGMA table_info(products)");
  const existing = (result.values || []).map(column => column.name);

  for (const [name, definition] of productColumns) {
    if (!existing.includes(name)) {
      await db.execute(
        `ALTER TABLE products ADD COLUMN ${name} ${definition}`
      );
    }
  }
}

async function setupIndexes() {
  const indexes = [
    "CREATE INDEX IF NOT EXISTS idx_products_name ON products(name)",
    "CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode)",
    "CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items(sale_id)",
    "CREATE INDEX IF NOT EXISTS idx_debt_customer ON debt_transactions(customer_id)",
    "CREATE INDEX IF NOT EXISTS idx_cash_created ON cash_transactions(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_expenses_created ON expenses(created_at)",
    "CREATE INDEX IF NOT EXISTS idx_purchase_items_purchase ON purchase_items(purchase_id)"
  ];
  for (const sql of indexes) await db.execute(sql);
}

export async function initDatabase() {
  if (db) return db;
  if (initializing) return initializing;

  initializing = (async () => {
    try {
      await ensureSQLitePlatform();
      // Capacitor Community SQLite exposes retrieveConnection(), not getConnection().
      // Reuse an existing connection when possible; otherwise create one safely.
      await sqlite.checkConnectionsConsistency();
      const connectionState = await sqlite.isConnection(DATABASE_NAME, false);
      if (connectionState?.result) {
        db = await sqlite.retrieveConnection(DATABASE_NAME, false);
      } else {
        db = await sqlite.createConnection(
          DATABASE_NAME,
          false,
          "no-encryption",
          1,
          false
        );
      }

      const isOpen = await db.isDBOpen();

      if (!isOpen.result) {
        await db.open();
      }

      await db.execute("PRAGMA foreign_keys = ON;");

      for (const query of schema) {
        await db.execute(query);
      }

      await migrateProducts();
      await setupIndexes();
      if (Capacitor.getPlatform() === "web") {
        await sqlite.saveToStore(DATABASE_NAME);
      }

      return db;
    } catch (error) {
      db = null;
      throw error;
    } finally {
      initializing = null;
    }
  })();

  return initializing;
}

export async function runQuery(sql, params = []) {
  if (!db) await initDatabase();

  const result = await db.run(sql, params);
  if (Capacitor.getPlatform() === "web") {
    await sqlite.saveToStore(DATABASE_NAME);
  }
  return result;
}

export async function getQuery(sql, params = []) {
  if (!db) await initDatabase();

  return await db.query(sql, params);
}

export async function executeTransaction(callback) {
  if (!db) await initDatabase();

  await db.execute("BEGIN TRANSACTION");

  try {
    const result = await callback({
      run: (sql, params = []) => db.run(sql, params),
      query: (sql, params = []) => db.query(sql, params)
    });

    await db.execute("COMMIT");
    if (Capacitor.getPlatform() === "web") {
      await sqlite.saveToStore(DATABASE_NAME);
    }
    return result;
  } catch (error) {
    try {
      await db.execute("ROLLBACK");
    } catch (rollbackError) {
      console.error("Rollback failed:", rollbackError);
    }

    throw error;
  }
}
