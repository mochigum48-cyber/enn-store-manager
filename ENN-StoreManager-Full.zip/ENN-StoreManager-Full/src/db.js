import * as SQLite from 'expo-sqlite';

let database;
export async function getDB(){
  if(database) return database;
  database = await SQLite.openDatabaseAsync('enn-store-manager.db');
  await database.execAsync(`
    PRAGMA journal_mode=WAL;
    PRAGMA foreign_keys=ON;
    CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,category TEXT DEFAULT '',unit TEXT DEFAULT 'ခု',buy_price REAL NOT NULL DEFAULT 0,sell_price REAL NOT NULL DEFAULT 0,wholesale_price REAL NOT NULL DEFAULT 0,stock REAL NOT NULL DEFAULT 0,low_stock REAL NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT DEFAULT '',area TEXT DEFAULT '',note TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product_name TEXT NOT NULL,customer_id INTEGER,customer_name TEXT DEFAULT '',qty REAL NOT NULL,unit_price REAL NOT NULL,total REAL NOT NULL,paid REAL NOT NULL DEFAULT 0,payment_type TEXT NOT NULL DEFAULT 'cash',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,product_name TEXT NOT NULL,qty REAL NOT NULL,unit_cost REAL NOT NULL,total REAL NOT NULL,paid REAL NOT NULL DEFAULT 0,supplier TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS debt_entries(id INTEGER PRIMARY KEY AUTOINCREMENT,customer_id INTEGER NOT NULL,kind TEXT NOT NULL,amount REAL NOT NULL,due_date TEXT,note TEXT DEFAULT '',created_at TEXT NOT NULL,FOREIGN KEY(customer_id) REFERENCES customers(id));
    CREATE TABLE IF NOT EXISTS cashbook(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,amount REAL NOT NULL,category TEXT DEFAULT '',note TEXT DEFAULT '',ref_type TEXT DEFAULT '',ref_id INTEGER,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,category TEXT DEFAULT '',amount REAL NOT NULL,note TEXT DEFAULT '',created_at TEXT NOT NULL);
  `);
  return database;
}
export const now=()=>new Date().toISOString();
export async function setting(key, fallback=''){const d=await getDB();const r=await d.getFirstAsync('SELECT value FROM settings WHERE key=?',[key]);return r?.value??fallback;}
export async function setSetting(key,value){const d=await getDB();await d.runAsync('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',[key,String(value)]);}
export async function totals(){const d=await getDB();const sales=await d.getFirstAsync("SELECT COALESCE(SUM(total),0) v FROM sales WHERE date(created_at)=date('now','localtime')");const cash=await d.getFirstAsync("SELECT COALESCE(SUM(CASE WHEN kind='in' THEN amount ELSE -amount END),0) v FROM cashbook");const debt=await d.getFirstAsync("SELECT COALESCE(SUM(CASE WHEN kind='debt' THEN amount ELSE -amount END),0) v FROM debt_entries");const stock=await d.getFirstAsync('SELECT COALESCE(SUM(stock*buy_price),0) v FROM products');const expenses=await d.getFirstAsync("SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date(created_at)=date('now','localtime')");const cogs=await d.getFirstAsync("SELECT COALESCE(SUM(qty*(SELECT buy_price FROM products p WHERE p.id=sales.product_id)),0) v FROM sales WHERE date(created_at)=date('now','localtime')");return {todaySales:sales.v,cash:cash.v,debt:debt.v,stock:stock.v,todayExpenses:expenses.v,todayProfit:sales.v-cogs.v-expenses.v};}
