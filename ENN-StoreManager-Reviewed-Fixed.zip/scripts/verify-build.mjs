import fs from 'node:fs';
import path from 'node:path';

const required = [
  'index.html',
  'dashboard.html',
  'setup.html',
  'products.html',
  'sales.html',
  'purchase.html',
  'debts.html',
  'expenses.html',
  'reports.html',
  'assets/music/music1.mp3',
  'assets/music/music2.mp3'
];

const dist = path.resolve('dist');
const missing = required.filter(file => {
  const target = path.join(dist, file);
  return !fs.existsSync(target) || !fs.statSync(target).isFile() || fs.statSync(target).size === 0;
});

if (missing.length) {
  console.error('Build verification failed. Missing or empty files in dist/:');
  for (const file of missing) console.error(` - ${file}`);
  process.exit(1);
}

// Check that every local page link used by the home navigation resolves.
const home = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');
const appSource = fs.readFileSync(path.resolve('www/js/app.js'), 'utf8');
const expectedPages = ['home', 'sales', 'products', 'debts', 'purchases', 'expenses', 'reports', 'settings'];
const missingRoutes = expectedPages.filter(page => !appSource.includes(`${page}:`));
if (!home.includes('data-page=') || missingRoutes.length) {
  console.error('Build verification failed. Home navigation route setup is incomplete.');
  for (const page of missingRoutes) console.error(` - route: ${page}`);
  process.exit(1);
}

console.log(`Build verification passed: ${required.length} required pages/assets and home navigation routes found.`);
