import fs from 'node:fs';
import path from 'node:path';

const required = [
  'index.html','dashboard.html','setup.html','products.html','sales.html',
  'purchase.html','purchases.html','debts.html','expenses.html','reports.html',
  'cashbook.html','settings.html','assets/music/music1.mp3','assets/music/music2.mp3','assets/sql-wasm.wasm'
];
const dist = path.resolve('dist');
const missing = required.filter(file => {
  const target = path.join(dist, file);
  return !fs.existsSync(target) || !fs.statSync(target).isFile() || fs.statSync(target).size === 0;
});
if (missing.length) {
  console.error('Build verification failed. Missing or empty files in dist/:');
  for (const file of missing) console.error(` - ${file}`);
  process.exit(1);
}

const pages = required.filter(file => file.endsWith('.html'));
const htmlFiles = pages.map(file => [file, fs.readFileSync(path.join(dist,file),'utf8')]);
for (const [page, html] of htmlFiles) {
  if (!/<script[^>]+type=["']module["'][^>]+src=["'][^"']+\/assets\/[^"']+\.js/.test(html)) {
    console.error(`Build verification failed: ${page} does not load a Vite-built JS entry from dist/assets/.`);
    process.exit(1);
  }
  if (/src=["'][^"']*\/js\/[^"']+\.js/.test(html)) {
    console.error(`Build verification failed: ${page} still points to an unbundled source module.`);
    process.exit(1);
  }
}
const assetDir = path.join(dist,'assets');
const jsFiles = fs.readdirSync(assetDir).filter(name => name.endsWith('.js'));
if (!jsFiles.length) {
  console.error('Build verification failed: no bundled JavaScript assets found.');
  process.exit(1);
}
const bundledJs = jsFiles.map(name => fs.readFileSync(path.join(assetDir,name),'utf8')).join('\n');
if (!bundledJs.includes('enn-persistent-audio') || !bundledJs.includes('popstate') || !bundledJs.includes('initWebStore') || !bundledJs.includes('jeep-sqlite')) {
  console.error('Build verification failed: persistent player or Back navigation is missing.');
  process.exit(1);
}

const databaseSource = fs.readFileSync(path.resolve('www/js/database.js'),'utf8');
if (/\bapplyPolyfills\b/.test(databaseSource)) {
  console.error('Build verification failed: jeep-sqlite applyPolyfills is not available in the pinned jeep-sqlite version.');
  process.exit(1);
}
if (!databaseSource.includes('defineCustomElements as defineJeepSqlite')) {
  console.error('Build verification failed: jeep-sqlite custom elements are not registered.');
  process.exit(1);
}

const bareImports = [
  /from\s*["']@capacitor-community\/sqlite["']/,
  /from\s*["']@capacitor\/app["']/,
  /import\s*\(\s*["']@capacitor-community\/sqlite["']\s*\)/,
  /import\s*\(\s*["']@capacitor\/app["']\s*\)/
];
for (const pattern of bareImports) {
  if (pattern.test(bundledJs)) {
    console.error(`Build verification failed: unbundled package import remains (${pattern}).`);
    process.exit(1);
  }
}
console.log(`Build verification passed: ${required.length} required pages/assets, Vite-built page scripts, bundled SQLite web/native modules, navigation, and persistent music shell found.`);
