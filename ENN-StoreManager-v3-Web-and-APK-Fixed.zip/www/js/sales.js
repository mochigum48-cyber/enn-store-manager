
import {
  initDatabase,
  getQuery,
  executeTransaction
} from "./database.js";

const $ = id => document.getElementById(id);

let products = [];
let cart = [];
let lastReceipt = null;

const money = value =>
  Math.round(Number(value || 0)).toLocaleString("en-US") + " Ks";

function showMessage(text, error = false) {
  $("message").textContent = text;
  $("message").style.color = error ? "#ff7777" : "#65d9a0";
}

async function loadProducts() {
  const result = await getQuery(`
    SELECT id, name, quantity, unit,
           purchase_price, selling_price,
           wholesale_price, wholesale_min_qty
    FROM products
    ORDER BY name COLLATE NOCASE
  `);

  products = result.values || [];
  displayProducts(products);
}

function displayProducts(items) {
  const container = $("product-results");
  container.replaceChildren();

  if (!items.length) {
    container.textContent = "ကုန်ပစ္စည်း မတွေ့ပါ။";
    return;
  }

  items.forEach(product => {
    const row = document.createElement("div");
    row.className = "product-result";

    const info = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = product.name;

    const detail = document.createElement("div");
    detail.className = "muted";
    detail.textContent =
      `လက်ကျန် ${product.quantity} ${product.unit} • ` +
      `လက်လီ ${money(product.selling_price)}`;

    info.append(name, detail);

    const button = document.createElement("button");
    button.className = "primary";
    button.textContent = "ထည့်မည်";
    button.disabled = Number(product.quantity) <= 0;

    button.addEventListener("click", () => addToCart(product));

    row.append(info, button);
    container.appendChild(row);
  });
}

function addToCart(product) {
  const existing = cart.find(item => item.id === product.id);

  if (existing) {
    if (existing.quantity + 1 > Number(product.quantity)) {
      showMessage("လက်ကျန်ပစ္စည်း မလုံလောက်ပါ။", true);
      return;
    }

    existing.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      stock: Number(product.quantity),
      unit: product.unit,
      cost: Number(product.purchase_price),
      retailPrice: Number(product.selling_price),
      wholesalePrice: Number(product.wholesale_price),
      wholesaleMin: Number(product.wholesale_min_qty) || 1,
      quantity: 1,
      price: Number(product.selling_price)
    });
  }

  renderCart();
}

function renderCart() {
  const container = $("cart-list");
  container.replaceChildren();

  if (!cart.length) {
    container.textContent = "ကုန်ပစ္စည်း မရွေးရသေးပါ။";
  }

  cart.forEach(item => {
    const row = document.createElement("div");
    row.className = "cart-item";

    const info = document.createElement("div");
    info.className = "cart-left";

    const name = document.createElement("strong");
    name.textContent = item.name;

    const price = document.createElement("div");
    price.className = "muted";
    price.textContent = money(item.price) + " / " + item.unit;

    const subtotal = document.createElement("div");
    subtotal.className = "muted";
    subtotal.textContent = "ကျသင့်ငွေ: " +
      money(item.price * item.quantity);

    info.append(name, price, subtotal);

    const actions = document.createElement("div");
    actions.className = "cart-actions";

    const quantity = document.createElement("input");
    quantity.type = "number";
    quantity.min = "0.01";
    quantity.step = "0.01";
    quantity.value = item.quantity;
    quantity.setAttribute("aria-label", item.name + " အရေအတွက်");

    quantity.addEventListener("change", () => {
      const value = Number(quantity.value);

      if (!Number.isFinite(value) || value <= 0 ||
          value > item.stock) {
        showMessage("အရေအတွက် မှန်ကန်စွာ ထည့်ပါ။ လက်ကျန် " +
          item.stock + " " + item.unit + " သာရှိပါတယ်။", true);
        quantity.value = item.quantity;
        return;
      }

      item.quantity = value;
      renderCart();
    });

    const remove = document.createElement("button");
    remove.className = "secondary";
    remove.textContent = "ဖယ်မည်";

    remove.addEventListener("click", () => {
      cart = cart.filter(p => p.id !== item.id);
      renderCart();
    });

    actions.append(quantity, remove);
    row.append(info, actions);
    container.appendChild(row);
  });

  updateTotals();
}

async function loadSalesHistory(){const box=$('sales-history');if(!box)return;const r=await getQuery(`SELECT s.id,s.total,s.paid,s.debt,s.created_at,c.name customer FROM sales s LEFT JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 20`);box.replaceChildren();for(const sale of (r.values||[])){const row=document.createElement('div');row.className='product-result';const info=document.createElement('span');info.textContent=`#${sale.id} · ${sale.customer||'ငွေသား'} · ${money(sale.total)} · ${sale.created_at}`;const del=document.createElement('button');del.className='secondary';del.textContent='ပယ်ဖျက်';del.onclick=async()=>{if(!confirm(`အရောင်း #${sale.id} ကို ပယ်ဖျက်ပြီး Stock/Cash/Debt ကို ပြန်ပြင်မလား?`))return;try{await executeTransaction(async tx=>{const items=await tx.query('SELECT product_id,quantity FROM sale_items WHERE sale_id=?',[sale.id]);for(const it of (items.values||[]))await tx.run('UPDATE products SET quantity=quantity+? WHERE id=?',[it.quantity,it.product_id]);await tx.run('DELETE FROM debt_transactions WHERE sale_id=?',[sale.id]);await tx.run("DELETE FROM cash_transactions WHERE reference_type='sale' AND reference_id=?",[sale.id]);await tx.run('DELETE FROM sale_items WHERE sale_id=?',[sale.id]);await tx.run('DELETE FROM sales WHERE id=?',[sale.id]);});showMessage('အရောင်းကို ပယ်ဖျက်ပြီး Stock/ငွေစာရင်း ပြန်ညှိပြီးပါပြီ။');await loadProducts();await loadSalesHistory();}catch(e){showMessage('ပယ်ဖျက်မရပါ: '+e.message,true);}};row.append(info,del);box.append(row);}}

function getTotal() {
  return cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );
}

function updateTotals() {
  const total = getTotal();
  const type = $("sale-type").value;

  let paid = Number($("paid").value) || 0;

  if (type === "cash") paid = total;
  if (type === "credit") paid = 0;

  $("total").textContent = money(total);
  $("paid-preview").textContent = money(paid);
  $("debt-preview").textContent = money(Math.max(0, total - paid));

  if (type === "cash") $("paid").value = total;
  if (type === "credit") $("paid").value = 0;

  $("customer-area").classList.toggle(
    "hidden",
    type === "cash"
  );

  $("paid-area").classList.toggle(
    "hidden",
    type === "credit"
  );
}

$("product-search").addEventListener("input", event => {
  const keyword = event.target.value.trim().toLowerCase();

  displayProducts(products.filter(product =>
    product.name.toLowerCase().includes(keyword)
  ));
});

$("sale-type").addEventListener("change", () => {
  updateTotals();
});

$("paid").addEventListener("input", updateTotals);

function getPaymentDetails() {
  const total = getTotal();
  const type = $("sale-type").value;

  let paid = 0;

  if (type === "cash") {
    paid = total;
  } else if (type === "partial") {
    paid = Number($("paid").value);
  }

  if (!Number.isFinite(paid) || paid < 0 || paid > total) {
    throw new Error("ပေးချေငွေ မှန်ကန်စွာ ထည့်ပါ။");
  }

  const debt = total - paid;

  if (debt > 0 && !$("customer-name").value.trim()) {
    throw new Error("အကြွေးရောင်းရန် ဝယ်သူအမည် ဖြည့်ပါ။");
  }

  return { total, paid, debt, type };
}

async function completeSale() {
  const button = $("complete-sale");
  button.disabled = true;

  try {
    if (!cart.length) {
      throw new Error("အရောင်းခြင်းတောင်းထဲ ကုန်ပစ္စည်းထည့်ပါ။");
    }

    const payment = getPaymentDetails();
    const soldItems = cart.map(item => ({...item}));
    const customerName = $("customer-name").value.trim();
    const phone = $("customer-phone").value.trim();

    const saleId = await executeTransaction(async tx => {
      let customerId = null;

      if (payment.debt > 0) {
        const existing = await tx.query(
          `SELECT id FROM customers
           WHERE name = ? AND phone = ?
           LIMIT 1`,
          [customerName, phone]
        );

        if (existing.values?.length) {
          customerId = existing.values[0].id;
        } else {
          const customer = await tx.run(
            `INSERT INTO customers (name, phone)
             VALUES (?, ?)`,
            [customerName, phone]
          );

          customerId = customer.changes?.lastId;
        }
      }

      const sale = await tx.run(
        `INSERT INTO sales
          (customer_id, total, paid, debt, payment_type)
         VALUES (?, ?, ?, ?, ?)`,
        [
          customerId,
          payment.total,
          payment.paid,
          payment.debt,
          payment.type
        ]
      );

      const newSaleId = sale.changes?.lastId;

      if (!newSaleId) {
        throw new Error("အရောင်းနံပါတ် မရရှိပါ။");
      }

      for (const item of cart) {
        const current = await tx.query(
          `SELECT quantity, purchase_price
           FROM products WHERE id = ?`,
          [item.id]
        );

        if (!current.values?.length) {
          throw new Error(item.name + " မတွေ့ပါ။");
        }

        const product = current.values[0];

        if (Number(product.quantity) < item.quantity) {
          throw new Error(
            item.name + " လက်ကျန် မလုံလောက်ပါ။"
          );
        }

        const cost = Number(product.purchase_price);
        const subtotal = item.price * item.quantity;

        await tx.run(
          `INSERT INTO sale_items
            (sale_id, product_id, quantity, price,
             cost_price, subtotal)
           VALUES (?, ?, ?, ?, ?, ?)`,
          [
            newSaleId,
            item.id,
            item.quantity,
            item.price,
            cost,
            subtotal
          ]
        );

        const updated = await tx.run(
          `UPDATE products
           SET quantity = quantity - ?,
               updated_at = CURRENT_TIMESTAMP
           WHERE id = ? AND quantity >= ?`,
          [item.quantity, item.id, item.quantity]
        );

        if (!updated.changes?.changes) {
          throw new Error(
            item.name + " Stock ပြောင်းလဲမှု မအောင်မြင်ပါ။"
          );
        }
      }

      // Only money actually received is recorded as cash.
      if (payment.paid > 0) {
        await tx.run(
          `INSERT INTO cash_transactions
            (type, amount, reference_type, reference_id, note)
           VALUES ('sale', ?, 'sale', ?, ?)`,
          [
            payment.paid,
            newSaleId,
            "အရောင်းငွေ"
          ]
        );
      }

      // Unpaid amount becomes a customer debt, not cash.
      if (payment.debt > 0) {
        await tx.run(
          `INSERT INTO debt_transactions
            (customer_id, sale_id, type, amount, note)
           VALUES (?, ?, 'charge', ?, ?)`,
          [
            customerId,
            newSaleId,
            payment.debt,
            "အကြွေးအရောင်း"
          ]
        );
      }

      return newSaleId;
    });

    lastReceipt={saleId,items:soldItems,payment,customerName,createdAt:new Date().toLocaleString()};
    const receiptButton=$('print-receipt');if(receiptButton)receiptButton.hidden=false;
    showMessage(`အရောင်းအောင်မြင်ပါပြီ။ အရောင်းနံပါတ် #${saleId}`);

    cart = [];
    $("customer-name").value = "";
    $("customer-phone").value = "";
    $("paid").value = 0;

    renderCart();
    await loadProducts();
    await loadSalesHistory();
    updateTotals();

  } catch (error) {
    console.error("Sale error:", error);
    showMessage(error.message || "အရောင်းသိမ်းမရပါ။", true);
  } finally {
    button.disabled = false;
  }
}

$("complete-sale").addEventListener("click", completeSale);

async function start() {
  try {
    await initDatabase();
    await loadProducts();
    await loadSalesHistory();
    renderCart();
    updateTotals();
  } catch (error) {
    console.error(error);
    showMessage(
      "Database ချိတ်ဆက်မရပါ။ " + error.message,
      true
    );
  }
}

start();

$('print-receipt')?.addEventListener('click',()=>{if(!lastReceipt)return;const r=lastReceipt;const lines=r.items.map(i=>`<tr><td>${i.name}</td><td>${i.quantity}</td><td>${money(i.price)}</td><td>${money(i.price*i.quantity)}</td></tr>`).join('');const w=window.open('','_blank','width=420,height=650');if(!w){showMessage('ဘောင်ချာဖွင့်ရန် Browser popup ခွင့်ပြုပါ။',true);return;}w.document.write(`<!doctype html><html lang="my"><meta charset="utf-8"><title>Receipt #${r.saleId}</title><style>body{font-family:Arial,sans-serif;padding:18px;color:#222}h2,p{text-align:center}table{width:100%;border-collapse:collapse;font-size:12px}td,th{border-bottom:1px solid #ddd;padding:7px;text-align:left}.total{text-align:right;font-weight:bold;margin-top:16px}@media print{button{display:none}}</style><h2>ENN Store Manager</h2><p>အရောင်းဘောင်ချာ #${r.saleId}<br>${r.createdAt}</p><p>${r.customerName||'ငွေသားဝယ်ယူသူ'}</p><table><thead><tr><th>ပစ္စည်း</th><th>အရေအတွက်</th><th>ဈေး</th><th>ကျသင့်ငွေ</th></tr></thead><tbody>${lines}</tbody></table><p class="total">စုစုပေါင်း: ${money(r.payment.total)}<br>ပေးပြီး: ${money(r.payment.paid)}<br>အကြွေး: ${money(r.payment.debt)}</p><p>ကျေးဇူးတင်ပါသည်။</p><script>window.onload=()=>window.print()<\/script></html>`);w.document.close();});
