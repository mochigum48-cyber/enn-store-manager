
import {
  initDatabase,
  getQuery
} from "./database.js";

const money = value =>
  Number(value || 0).toLocaleString("en-US") + " Ks";

async function getSetting(key) {
  const result = await getQuery(
    "SELECT value FROM settings WHERE key = ?",
    [key]
  );

  return result.values?.[0]?.value ?? "";
}

async function loadDashboard() {
  const errorBox = document.getElementById("dashboard-error");

  try {
    errorBox.textContent = "";

    await initDatabase();

    // Shop name and opening cash
    const shopName = await getSetting("shop_name");
    const openingCash = Number(
      await getSetting("opening_cash") || 0
    );

    document.getElementById("shop-name").textContent =
      shopName || "Grocery Store";

    document.getElementById("opening-cash").textContent =
      money(openingCash);

    // Cash balance
    const cashResult = await getQuery(`
      SELECT COALESCE(SUM(
        CASE
          WHEN type IN (
            'opening_balance',
            'cash_in',
            'sale',
            'debt_payment',
            'purchase_refund'
          ) THEN amount

          WHEN type IN (
            'cash_out',
            'expense',
            'purchase'
          ) THEN -amount

          ELSE 0
        END
      ), 0) AS balance
      FROM cash_transactions
    `);

    const cashBalance =
      Number(cashResult.values?.[0]?.balance || 0);

    document.getElementById("cash-balance").textContent =
      money(cashBalance);

    // Product count
    const productResult = await getQuery(`
      SELECT COUNT(*) AS total
      FROM products
    `);

    document.getElementById("product-count").textContent =
      Number(productResult.values?.[0]?.total || 0)
        .toLocaleString() + " မျိုး";

    // Inventory value based on purchase cost
    const inventoryResult = await getQuery(`
      SELECT COALESCE(
        SUM(quantity * purchase_price), 0
      ) AS total
      FROM products
    `);

    document.getElementById("inventory-value").textContent =
      money(inventoryResult.values?.[0]?.total);

    // Low stock count
    const lowStockResult = await getQuery(`
      SELECT COUNT(*) AS total
      FROM products
      WHERE quantity <= min_stock
    `);

    document.getElementById("low-stock-count").textContent =
      Number(lowStockResult.values?.[0]?.total || 0)
        .toLocaleString() + " မျိုး";

    // Today's sales
    const salesResult = await getQuery(`
      SELECT COALESCE(SUM(total), 0) AS total
      FROM sales
      WHERE date(created_at, 'localtime') =
            date('now', 'localtime')
    `);

    document.getElementById("today-sales").textContent =
      money(salesResult.values?.[0]?.total);

    // Today's expenses
    const expenseResult = await getQuery(`
      SELECT COALESCE(SUM(amount), 0) AS total
      FROM expenses
      WHERE date(created_at, 'localtime') =
            date('now', 'localtime')
    `);

    document.getElementById("today-expenses").textContent =
      money(expenseResult.values?.[0]?.total);

    // Low stock product list
    const lowProducts = await getQuery(`
      SELECT name, quantity, unit, min_stock
      FROM products
      WHERE quantity <= min_stock
      ORDER BY quantity ASC
      LIMIT 10
    `);

    const lowList = document.getElementById("low-stock-list");
    lowList.replaceChildren();

    if (!lowProducts.values?.length) {
      lowList.textContent = "လက်ကျန်နည်းနေသော ပစ္စည်းမရှိပါ။";
    } else {
      lowProducts.values.forEach(product => {
        const item = document.createElement("div");
        item.className = "low-stock-item";

        item.textContent =
          `⚠️ ${product.name} — ${product.quantity} ${product.unit} ` +
          `(သတိပေးအဆင့် ${product.min_stock})`;

        lowList.appendChild(item);
      });
    }

    document.getElementById("last-updated").textContent =
      new Date().toLocaleString();

  } catch (error) {
    console.error("Dashboard error:", error);

    errorBox.textContent =
      "Database ဖတ်မရပါ။ Android SQLite Plugin နဲ့ Build လုပ်ပြီးမှ စမ်းသပ်ပါ။";
  }
}

document.getElementById("refresh-dashboard")
  .addEventListener("click", loadDashboard);

loadDashboard();
