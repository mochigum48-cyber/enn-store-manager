# Build fix notes

The previous GitHub Actions failure was caused by a filename mismatch: the project built `dist/purchase.html`, while the repository's verification expected `dist/purchases.html`.

This package keeps the original singular page and adds a plural alias. Vite builds both names, the build verifier checks both, and the workflow checks both. Existing links to `purchase.html` remain valid.
