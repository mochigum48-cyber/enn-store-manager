# Build and verification status

This archive contains the full web source project and a GitHub Actions workflow for building a debug Android APK.

## Included checks
- Vite multi-page build configuration for all nine HTML pages.
- Build verification for all nine pages and both bundled MP3 tracks.
- Node syntax checks for the JavaScript source and verification script.
- GitHub Actions workflow installs Java 21, Node 20, Android SDK packages, dependencies, builds the web app, creates/syncs the Capacitor Android project, and runs Gradle `assembleDebug`.

## Important limitations
- The ZIP itself is source code, not an APK.
- A successful GitHub Actions run is needed to confirm the APK build.
- The APK has not been installed or tested on a physical Android phone in this environment.
- The project currently uses Capacitor's default launcher icon; the custom For Ma Ma artwork is not packaged as Android launcher density assets.
- Music files are bundled as `www/public/assets/music/music1.mp3` and `music2.mp3` and are copied into the Vite output as `dist/assets/music/`.

See `UPLOAD-TO-GITHUB.md` for the exact upload procedure. Upload the extracted ZIP contents to the repository root, not the ZIP file itself.
