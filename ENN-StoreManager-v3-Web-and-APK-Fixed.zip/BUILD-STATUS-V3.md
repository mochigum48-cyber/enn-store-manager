# ENN Store Manager v3 - Build Status

This is a v3 source package based on the supplied v3 archive; v2 was not overwritten.

Included in this revision:
- Global persistent header music player; import audio files from the device and keep them in IndexedDB.
- Persistent music state across internal page navigation.
- Global Back and Dashboard navigation; Android hardware Back integration through Capacitor App.
- Customer list with name, phone, address, debt balance and repayment history.
- Product barcode field, barcode search, and low-stock warning.
- Cashbook manual cash-in/cash-out and daily balance summary.
- Seven-day sales/expense chart and existing daily/monthly profit summaries.
- JSON database backup/restore and sales CSV export (Excel-compatible CSV, not XLSX).
- Printable sales receipt.
- Safe cancellation/deletion of sales and purchases with stock/cash/debt reversal where linked records exist.
- Dark mode and PIN gate.

Validation performed in this workspace: JavaScript syntax checks passed. Full Vite/Android build was not run because dependency installation timed out in this environment. Please use the included GitHub Actions workflow to perform the Android build. Do not treat this package as a verified APK until that workflow succeeds.

Known scope note: transaction editing is currently handled by canceling a record with accounting reversal and entering it again; in-place edit forms for historical sales/purchases are not implemented. CSV export currently exports sales headers only.
