# Upload this project to GitHub (important)

This ZIP is the **source project archive**, not an APK. Do not upload this ZIP as a single file to the repository.

1. Download this ZIP and extract it on your phone.
2. Open the extracted folder. The first level must show `package.json`, `vite.config.js`, `capacitor.config.json`, `www/`, `scripts/`, and `.github/`.
3. In the GitHub repository, remove the previously uploaded project ZIP file and the old source files if they conflict.
4. Upload the **contents inside the extracted folder** to the repository root. Do not upload the containing folder itself and do not upload the ZIP file.
5. Confirm that GitHub's Code page shows `package.json`, `vite.config.js`, `www/`, `scripts/`, and `.github/workflows/android-apk.yml` at the repository root.
6. Open Actions and run **Build ENN Store Manager APK**. Wait for the run to finish. Download `ENN-StoreManager-debug-apk` from the successful run's Artifacts section.

The workflow builds a debug APK. A successful GitHub Actions run is still required to verify the Android build; the archive has not been device-tested.
