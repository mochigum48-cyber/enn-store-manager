import fs from 'node:fs';
import path from 'node:path';

const required = [
  'index.html', 'dashboard.html', 'setup.html', 'products.html',
  'sales.html', 'purchase.html', 'debts.html', 'expenses.html',
  'reports.html', 'assets/music/music1.mp3', 'assets/music/music2.mp3'
];
const dist = path.resolve('dist');
const missing = required.filter((file) => !fs.existsSync(path.join(dist, file)));
if (missing.length) {
  console.error('Build verification failed. Missing files in dist/:');
  for (const file of missing) console.error(` - ${file}`);
  process.exit(1);
}
console.log(`Build verification passed: ${required.length} required pages/assets found.`);
