# ENN Store Manager — Browser + APK SQLite Fix

## Changes
- Added the documented `jeep-sqlite` web implementation and pinned `sql.js` to 1.11.0 so the loader and WASM runtime stay aligned.
- Added a build step to copy `sql-wasm.wasm` into `www/public/assets`, which Vite publishes as `dist/assets/sql-wasm.wasm`.
- `database.js` now initializes the jeep-sqlite IndexedDB store only on the Web platform; Android continues to use the native Capacitor SQLite plugin.
- Browser writes are persisted with `saveToStore` after normal writes and committed transactions.
- Added a GitHub Pages workflow for HTTPS Browser preview.
- Kept Back and Dashboard in the bottom action bar.
- Removed the barcode field and barcode search/display from the product UI.

## Important Browser opening rule
Do not open `www/index.html` or extracted source HTML with `file://`. That bypasses Vite and cannot resolve npm package imports. For Browser use, deploy the built `dist` site through GitHub Pages (HTTPS), or run the Vite dev server. The Browser database is stored in that browser's IndexedDB and is separate from the Android app's native database.

## Checks performed in this environment
- JavaScript syntax checks passed for all project JS files and build scripts.
- Package configuration and ZIP contents inspected.
- A full `npm install`, Vite production build, GitHub Pages deploy, and Android Gradle build were not run here because package installation/network access was unavailable. Do not treat this ZIP as a successfully built APK until the GitHub Actions workflows finish successfully.
