# ENN Store Manager — Native Offline Core

An original ENN-branded Android grocery shop manager built with React Native + Expo SDK 54 and SQLite. This is a source project, not a prebuilt APK. It is designed to be uploaded to GitHub and built with the included Actions workflow.

## Included working source features

- Offline SQLite database with WAL and foreign-key support.
- Dashboard: today's sales, estimated profit, cashbook balance, receivables, stock value.
- Product CRUD: name, category, unit, buy price, retail price, wholesale price, stock and low-stock threshold.
- Customer records: name, optional phone, neighborhood/address and note.
- Debt ledger: multiple debt entries per customer, due dates, editable latest due date, partial repayments, same-day multiple payments, current outstanding balance and transaction history.
- Sales: select product, quantity, unit price, cash/partial/credit payment, customer for credit; stock decreases and received cash / debt ledger are posted.
- Purchases: stock increases and weighted-average purchase cost is recalculated; paid amount reduces cash.
- Expenses: records expense and reduces cash.
- Cashbook: manual cash-in/cash-out records and automatically posted sales, purchase payments, expenses and debt repayments.
- Reports: key financial totals, printable report and XLSX export.
- Backup/restore: JSON backup of local database tables.
- Music: retains the four supplied tracks in the source playlist, allows selecting audio files from the phone, copies selected audio into app storage and remembers added tracks.
- PIN lock and dark theme setting.
- No QR code or barcode scanner.

## Important accounting behavior

- Credit sale: only amount actually received is added to cash; unpaid balance is posted as customer debt.
- Debt repayment: added to cashbook as cash-in and reduces the customer's debt; it is not counted as a new sale.
- Purchase: stock is increased and average purchase cost recalculated. Only amount paid is subtracted from cash.
- Expense: recorded as an expense and cash-out.
- Opening cash should be entered as a manual cash-in record labelled "Opening cash"; it is not sales income.

## Build APK with GitHub Actions

1. Extract this ZIP.
2. Create a GitHub repository and upload the contents of this folder to the repository root (not an extra nested folder).
3. Open **Actions** → **Build ENN Store Manager APK** → **Run workflow**.
4. When the workflow finishes successfully, open its run and download the `enn-store-manager-apk` artifact.
5. Extract the artifact ZIP to get the APK.

The first Android build may take several minutes. If Maven Central returns HTTP 429, rerun the workflow after a short wait.

## Local development

Requires Node.js 22 and Java 17 for Android builds.

```bash
npm install
npx expo start
```

For native Android:

```bash
npx expo prebuild --platform android
cd android
./gradlew assembleRelease
```

## Known limitations — not represented as completed

This source provides the offline shop-management core. It has not yet been built or device-tested in this environment. The following require a separate implementation phase and/or real device/account credentials: Firebase cloud sync, Bluetooth receipt-printer protocol and printer model testing, a true Android foreground/background audio service, advanced audit-safe edit/delete of historical sales and purchase transactions, supplier payable ledger, multi-user access, and production-grade accounting reconciliation. The current PDF report is a printable summary; XLSX export is provided for the available local tables. No online payment or subscription feature is included.

Always create a backup before reinstalling or clearing app data. SQLite data is stored locally on the device.
