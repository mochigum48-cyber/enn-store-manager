
import {
  initDatabase,
  getQuery,
  executeTransaction
} from "./database.js";

const $ = id => document.getElementById(id);

let products = [];

const money = value =>
  Math.round(Number(value || 0)).toLocaleString("en-US") + " Ks";

function showMessage(message, error = false) {
  $("message").textContent = message;
  $("message").style.color = error ? "#ff7777" : "#65d9a0";
}

function calculate() {
  const quantity = Number($("quantity").value) || 0;
  const cost = Number($("unit-cost").value) || 0;
  const total = quantity * cost;
  const paid = Number($("paid").value) || 0;

  $("purchase-total").textContent = money(total);
  $("total-preview").textContent = money(total);
  $("paid-preview").textContent = money(paid);
  $("unpaid-preview").textContent = money(Math.max(0, total - paid));
}

async function loadProducts() {
  const result = await getQuery(`
    SELECT id, name, quantity, unit, purchase_price
    FROM products
    ORDER BY name COLLATE NOCASE
  `);

  products = result.values || [];

  const select = $("product-select");
  select.replaceChildren();

  const placeholder = document.createElement("option");
  placeholder.value = "";
  placeholder.textContent = "ကုန်ပစ္စည်းရွေးပါ";
  select.appendChild(placeholder);

  products.forEach(product => {
    const option = document.createElement("option");
    option.value = product.id;
    option.textContent = product.name;
    select.appendChild(option);
  });
}

function updateProductInfo() {
  const product = products.find(
    item => item.id === Number($("product-select").value)
  );

  if (!product) {
    $("product-info").textContent = "ကုန်ပစ္စည်းရွေးပါ။";
    return;
  }

  $("product-info").textContent =
    `လက်ရှိ Stock: ${product.quantity} ${product.unit} • ` +
    `လက်ရှိ ပျမ်းမျှအရင်း: ${money(product.purchase_price)}`;
}

async function loadHistory() {
  const result = await getQuery(`
    SELECT
      p.id,
      p.supplier_name,
      p.total,
      p.paid,
      p.created_at,
      COUNT(pi.id) AS item_count
    FROM purchases p
    LEFT JOIN purchase_items pi ON pi.purchase_id = p.id
    GROUP BY p.id
    ORDER BY p.id DESC
    LIMIT 15
  `);

  const container = $("purchase-history");
  container.replaceChildren();

  if (!result.values?.length) {
    container.textContent = "ကုန်ဝယ်မှတ်တမ်း မရှိသေးပါ။";
    return;
  }

  result.values.forEach(item => {
    const row = document.createElement("div");
    row.className = "history-row";

    const left = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = `ကုန်ဝယ် #${item.id}`;

    const detail = document.createElement("div");
    detail.className = "muted";
    detail.textContent =
      `${item.supplier_name || "ပေးသွင်းသူ မသတ်မှတ်"} • ` +
      `${item.item_count} မျိုး`;

    left.append(title, detail);

    const right = document.createElement("div");
    right.style.textAlign = "right";

    const total = document.createElement("strong");
    total.textContent = money(item.total);

    const paid = document.createElement("div");
    paid.className = "muted";
    paid.textContent = `ပေးပြီး ${money(item.paid)}`;

    right.append(total, paid);
    const del=document.createElement('button');del.className='secondary';del.textContent='ပယ်ဖျက်';del.onclick=async()=>{if(!confirm(`ကုန်ဝယ် #${item.id} ကို ပယ်ဖျက်ပြီး Stock/ငွေစာရင်း ပြန်ညှိမလား?`))return;try{await executeTransaction(async tx=>{const its=await tx.query('SELECT product_id,quantity,cost_price FROM purchase_items WHERE purchase_id=?',[item.id]);for(const it of (its.values||[])){const cur=await tx.query('SELECT quantity,purchase_price FROM products WHERE id=?',[it.product_id]);if(!cur.values?.length)throw Error('ကုန်ပစ္စည်းမရှိပါ');const q=Number(cur.values[0].quantity),cost=Number(cur.values[0].purchase_price),remove=Number(it.quantity);if(q<remove)throw Error('လက်ရှိ Stock သည် ဝယ်ယူခဲ့သောအရေအတွက်ထက်နည်းနေ၍ ပယ်ဖျက်မရပါ။');const nq=q-remove;const oldCost=nq>0?Math.max(0,(q*cost-remove*Number(it.cost_price))/nq):0;await tx.run('UPDATE products SET quantity=?,purchase_price=? WHERE id=?',[nq,oldCost,it.product_id]);}await tx.run("DELETE FROM cash_transactions WHERE reference_type='purchase' AND reference_id=?",[item.id]);await tx.run('DELETE FROM purchase_items WHERE purchase_id=?',[item.id]);await tx.run('DELETE FROM purchases WHERE id=?',[item.id]);});showMessage('ကုန်ဝယ်မှတ်တမ်း ပယ်ဖျက်ပြီးပါပြီ။');await loadProducts();await loadHistory();}catch(e){showMessage(e.message,true);}};
    right.append(del);row.append(left, right);
    container.appendChild(row);
  });
}

$("product-select").addEventListener("change", updateProductInfo);

["quantity", "unit-cost", "paid"].forEach(id => {
  $(id).addEventListener("input", calculate);
});

$("save-purchase").addEventListener("click", async () => {
  const button = $("save-purchase");
  button.disabled = true;

  try {
    const productId = Number($("product-select").value);
    const quantity = Number($("quantity").value);
    const unitCost = Number($("unit-cost").value);
    const total = quantity * unitCost;
    const paid = Number($("paid").value);
    const supplier = $("supplier").value.trim();
    const note = $("note").value.trim();

    if (!productId) {
      throw new Error("ကုန်ပစ္စည်း ရွေးပေးပါ။");
    }

    if (!Number.isFinite(quantity) || quantity <= 0) {
      throw new Error("ဝယ်ယူအရေအတွက် မှန်ကန်စွာထည့်ပါ။");
    }

    if (!Number.isFinite(unitCost) || unitCost <= 0) {
      throw new Error("တစ်ခုချင်း ဝယ်ဈေး မှန်ကန်စွာထည့်ပါ။");
    }

    if (!Number.isFinite(paid) || paid < 0 || paid > total) {
      throw new Error("ပေးချေငွေကို 0 မှ စုစုပေါင်းတန်ဖိုးအတွင်း ထည့်ပါ။");
    }

    const product = products.find(item => item.id === productId);

    if (!product) {
      throw new Error("ကုန်ပစ္စည်းကို ရှာမတွေ့ပါ။");
    }

    const purchaseId = await executeTransaction(async tx => {
      const currentResult = await tx.query(
        `SELECT quantity, purchase_price
         FROM products
         WHERE id = ?`,
        [productId]
      );

      if (!currentResult.values?.length) {
        throw new Error("ကုန်ပစ္စည်း မရှိတော့ပါ။");
      }

      const current = currentResult.values[0];
      const oldQuantity = Number(current.quantity) || 0;
      const oldCost = Number(current.purchase_price) || 0;

      const newQuantity = oldQuantity + quantity;

      // Weighted average cost calculation
      const newAverageCost =
        newQuantity > 0
          ? (
              oldQuantity * oldCost +
              quantity * unitCost
            ) / newQuantity
          : unitCost;

      const purchaseResult = await tx.run(
        `INSERT INTO purchases
          (supplier_name, total, paid)
         VALUES (?, ?, ?)`,
        [supplier, total, paid]
      );

      const newPurchaseId = purchaseResult.changes?.lastId;

      if (!newPurchaseId) {
        throw new Error("ကုန်ဝယ်မှတ်တမ်း နံပါတ် မရပါ။");
      }

      await tx.run(
        `INSERT INTO purchase_items
          (purchase_id, product_id, quantity, cost_price, subtotal)
         VALUES (?, ?, ?, ?, ?)`,
        [newPurchaseId, productId, quantity, unitCost, total]
      );

      const updateResult = await tx.run(
        `UPDATE products
         SET quantity = ?,
             purchase_price = ?,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [newQuantity, newAverageCost, productId]
      );

      if (!updateResult.changes?.changes) {
        throw new Error("Stock နှင့် အရင်းဈေး ပြင်ဆင်မရပါ။");
      }

      // Only the amount actually paid is cash outflow.
      if (paid > 0) {
        await tx.run(
          `INSERT INTO cash_transactions
            (type, amount, reference_type, reference_id, note)
           VALUES ('purchase', ?, 'purchase', ?, ?)`,
          [paid, newPurchaseId, note || "ကုန်ဝယ်ငွေ"]
        );
      }

      return newPurchaseId;
    });

    showMessage(`ကုန်ဝယ်မှတ်တမ်း #${purchaseId} သိမ်းပြီးပါပြီ။`);

    $("quantity").value = "";
    $("unit-cost").value = "";
    $("paid").value = "";
    $("supplier").value = "";
    $("note").value = "";

    calculate();
    await loadProducts();
    updateProductInfo();
    await loadHistory();

  } catch (error) {
    console.error("Purchase error:", error);
    showMessage(error.message || "ကုန်ဝယ်စာရင်း သိမ်းမရပါ။", true);
  } finally {
    button.disabled = false;
  }
});

async function start() {
  try {
    await initDatabase();
    await loadProducts();
    await loadHistory();
    calculate();
  } catch (error) {
    console.error(error);
    showMessage(
      "Database ချိတ်ဆက်မှု မအောင်မြင်ပါ။ " + error.message,
      true
    );
  }
}

start();
