import {initDatabase,getQuery} from "./database.js";
const $=s=>document.querySelector(s), money=n=>Math.round(Number(n||0)).toLocaleString("en-US");
const today=new Date();
const date=$("#date-chip"), day=$("#today-label");
if(date)date.textContent=new Intl.DateTimeFormat("my-MM",{day:"numeric",month:"short",year:"numeric"}).format(today);
if(day)day.textContent=new Intl.DateTimeFormat("en",{weekday:"long"}).format(today).toUpperCase();
async function scalar(sql){const r=await getQuery(sql);return Number(r.values?.[0]?.v||0);}
async function load(){
 try{
  await initDatabase();
  const cash=await scalar(`SELECT COALESCE(SUM(CASE WHEN type IN('opening_balance','cash_in','sale','debt_payment','purchase_refund') THEN amount WHEN type IN('cash_out','expense','purchase') THEN -amount ELSE 0 END),0) v FROM cash_transactions`);
  const sales=await scalar(`SELECT COALESCE(SUM(total),0) v FROM sales WHERE date(created_at,'localtime')=date('now','localtime')`);
  const expenses=await scalar(`SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE date(created_at,'localtime')=date('now','localtime')`);
  const profit=await scalar(`SELECT COALESCE(SUM(si.subtotal-si.cost_price*si.quantity),0) v FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at,'localtime')=date('now','localtime')`);
  const products=await scalar("SELECT COUNT(*) v FROM products");
  const income=await scalar(`SELECT COALESCE(SUM(amount),0) v FROM cash_transactions WHERE type IN('opening_balance','cash_in','sale','debt_payment') AND date(created_at,'localtime')=date('now','localtime')`);
  const outcome=await scalar(`SELECT COALESCE(SUM(amount),0) v FROM cash_transactions WHERE type IN('cash_out','expense','purchase') AND date(created_at,'localtime')=date('now','localtime')`);
  const set=(id,v)=>{const e=$("#"+id);if(e)e.textContent=v;};
  set("cash-balance",money(cash)+" ကျပ်");set("income-total",money(income));set("outcome-total",money(outcome));
  set("sales-total",money(sales)+" ကျပ်");set("profit-total",money(profit)+" ကျပ်");set("expense-total",money(expenses)+" ကျပ်");set("product-count",money(products)+" မျိုး");
  const empty=document.querySelector(".empty-card");if(empty){empty.innerHTML="<strong>စာရင်းများကို Database မှ ဖတ်ရှုပြသနေပါသည်။</strong><p>အရောင်း၊ ကုန်ဝယ်၊ အသုံးစရိတ် စာရင်းများကို အောက်ပါခလုတ်များမှ ထည့်နိုင်ပါသည်။</p>";}
  const warning=document.querySelector(".demo-warning");if(warning)warning.remove();
 }catch(e){console.error(e);const w=document.querySelector(".demo-warning");if(w)w.textContent="Database ချိတ်ဆက်မှု မအောင်မြင်ပါ။ Android App အဖြစ် Build လုပ်ပြီး စမ်းသပ်ပါ။ "+e.message;}
}
load();
