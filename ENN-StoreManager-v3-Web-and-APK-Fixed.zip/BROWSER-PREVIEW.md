# Browser Preview (Important)

The source files in `www/` are Vite source modules. Do not open `www/index.html` or any extracted HTML file directly with the Android file manager (`file://`). Browser module imports such as `@capacitor-community/sqlite` are resolved by Vite during the build, not by opening source HTML files.

## Browser use
1. Push the project files to the `main` branch of the GitHub repository.
2. In GitHub, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
3. Wait for the **Deploy ENN Store Manager Browser App** workflow to finish successfully.
4. Open the published HTTPS GitHub Pages URL. Use that URL for Browser testing.

The browser build uses `jeep-sqlite` with IndexedDB persistence. Browser data is stored separately in that browser's site storage; it does not automatically sync with the Android APK database.

## Android APK
The Android build uses the native `@capacitor-community/sqlite` implementation. Install the APK artifact produced by the Android workflow.

## Development
Run `npm install` then `npm run start`. Open the Vite URL printed in the terminal; do not open source HTML via `file://`.
