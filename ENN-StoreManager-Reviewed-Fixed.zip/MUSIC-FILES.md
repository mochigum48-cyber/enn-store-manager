# Background music

The two audio files supplied for this build are included and converted to MP3:

- `www/assets/music/music1.mp3` — Kooper (uploaded first)
- `www/assets/music/music2.mp3` — Minor inconvenience (uploaded second)

The home screen plays `music1.mp3` first. The Next button switches to `music2.mp3`, and playback continues to the next track when a song ends.

To add more songs later, place MP3 files in `www/assets/music/` using the names `music3.mp3`, `music4.mp3`, etc., then add their relative paths to the `playlist` array in `www/js/app.js`.
