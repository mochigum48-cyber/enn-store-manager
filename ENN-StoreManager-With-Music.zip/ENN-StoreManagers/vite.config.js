import { defineConfig } from 'vite';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const projectDir = dirname(fileURLToPath(import.meta.url));
const pages = [
  'index.html',
  'dashboard.html',
  'setup.html',
  'products.html',
  'sales.html',
  'purchase.html',
  'debts.html',
  'expenses.html',
  'reports.html'
];

export default defineConfig({
  root: 'www',
  base: './',
  build: {
    outDir: '../dist',
    emptyOutDir: true,
    rollupOptions: {
      input: Object.fromEntries(
        pages.map((page) => [
          page.replace('.html', ''),
          resolve(projectDir, 'www', page)
        ])
      )
    }
  }
});
