import fs from 'node:fs';
import path from 'node:path';

const source = path.resolve('node_modules/sql.js/dist/sql-wasm.wasm');
const targetDir = path.resolve('www/public/assets');
const target = path.join(targetDir, 'sql-wasm.wasm');

if (!fs.existsSync(source)) {
  console.error('SQLite WebAssembly file not found. Run npm install first.');
  process.exit(1);
}
fs.mkdirSync(targetDir, { recursive: true });
fs.copyFileSync(source, target);
console.log('Copied SQLite WASM to www/public/assets/sql-wasm.wasm');
