import { initDatabase, runQuery, getQuery } from "./database.js";
const $ = id => document.getElementById(id);
const form = $("product-form"), list = $("product-list"), message = $("message");
let products = [];
const money = n => Math.round(Number(n || 0)).toLocaleString("en-US") + " Ks";
function show(text, error=false){ message.textContent=text; message.style.color=error?"#ff7777":"#65d9a0"; }
function values(){
  const name=$("name").value.trim(), unit=$("unit").value.trim();
  const packSize=Number($("pack-size").value), packCount=Number($("pack-count").value||0);
  const loose=Number($("loose-quantity").value||0), packCost=Number($("pack-cost").value);
  const retail=Number($("retail-margin").value||0), wholesale=Number($("wholesale-margin").value||0);
  const min=Number($("min-stock").value||0), minQty=Number($("wholesale-min").value||1);
  if(!name||!unit) throw Error("ကုန်ပစ္စည်းအမည်နဲ့ ယူနစ် ဖြည့်ပါ။");
  if(!(packSize>0)||packCount<0||loose<0||!(packCost>=0)||retail<0||wholesale<0||min<0||!(minQty>0)) throw Error("အရေအတွက်၊ ဈေးနှုန်းနဲ့ ရာခိုင်နှုန်းတွေ စစ်ဆေးပါ။");
  const cost=packCost/packSize, qty=packCount*packSize+loose;
  const retailPrice=Math.round(cost*(1+retail/100));
  const wholesalePrice=Math.round(cost*(1+wholesale/100));
  return {name,category:$("category").value.trim()||"အထွေထွေ",unit,packName:$("pack-name").value.trim()||"Pack",packSize,packCount,loose,packCost,cost,qty,retail,wholesale,min,minQty,retailPrice,wholesalePrice};
}
function preview(){
 try{
  const v=values();
  $("unit-cost").value=money(v.cost);
  $("retail-unit-preview").textContent=money(v.retailPrice);
  $("retail-pack-preview").textContent=money(v.retailPrice*v.packSize);
  $("wholesale-unit-preview").textContent=money(v.wholesalePrice);
  $("wholesale-pack-preview").textContent=money(v.wholesalePrice*v.packSize);
  $("retail-profit-preview").textContent=money((v.retailPrice-v.cost)*v.packSize);
 }catch{ ["unit-cost","retail-unit-preview","retail-pack-preview","wholesale-unit-preview","wholesale-pack-preview","retail-profit-preview"].forEach(id=>{const e=$(id);if(e)e.textContent="0 Ks";});}
}
async function load(){
 const r=await getQuery("SELECT * FROM products ORDER BY name COLLATE NOCASE");
 products=r.values||[]; render(products);
}
function render(items){
 list.replaceChildren();
 if(!items.length){list.textContent="ကုန်ပစ္စည်း မရှိသေးပါ။";return;}
 for(const p of items){
  const card=document.createElement("article");card.className="product-card";
  const h=document.createElement("h3");h.textContent=p.name;
  const d=document.createElement("div");d.className="product-detail";
  d.textContent=`အရင်း: ${money(p.purchase_price)} / ${p.unit}\\nလက်လီ: ${money(p.selling_price)}\\nလက်ကား: ${money(p.wholesale_price)}\\nလက်ကျန်: ${p.quantity} ${p.unit}`;
  const actions=document.createElement("div");actions.className="product-actions";
  const edit=document.createElement("button");edit.className="light-btn";edit.textContent="ပြင်ဆင်ရန်";edit.onclick=()=>editProduct(p);
  const del=document.createElement("button");del.className="danger-btn";del.textContent="ဖျက်ရန်";del.onclick=()=>deleteProduct(p);
  actions.append(edit,del);card.append(h,d,actions);list.append(card);
 }
}
function editProduct(p){
 $("product-id").value=p.id;$("name").value=p.name;
 $("category").value=p.category||"";$("pack-name").value=p.pack_name||"Pack";
 const size=Number(p.pack_size)||1;$("pack-size").value=size;
 $("pack-count").value=Math.floor(Number(p.quantity)/size);
 $("loose-quantity").value=Number(p.quantity)%size;
 $("pack-cost").value=Number(p.pack_purchase_price)||Number(p.purchase_price)*size;
 $("retail-margin").value=p.retail_margin_pct??15;$("wholesale-margin").value=p.wholesale_margin_pct??10;
 $("wholesale-min").value=p.wholesale_min_qty||1;$("unit").value=p.unit;$("min-stock").value=p.min_stock||0;
 $("form-title").textContent="✏️ ကုန်ပစ္စည်း ပြင်ဆင်ရန်";
 $("cancel-edit").classList.remove("hidden");preview();$("form-panel").scrollIntoView({behavior:"smooth"});
}
function reset(){form.reset();$("product-id").value="";$("pack-name").value="Pack";$("pack-size").value=12;$("pack-count").value=0;$("loose-quantity").value=0;$("pack-cost").value=0;$("retail-margin").value=15;$("wholesale-margin").value=10;$("wholesale-min").value=6;$("min-stock").value=5;$("form-title").textContent="➕ ကုန်ပစ္စည်းအသစ်ထည့်ရန်";$("cancel-edit").classList.add("hidden");preview();}
async function deleteProduct(p){
 if(!confirm(`${p.name} ကို ဖျက်မှာ သေချာပါသလား။ အရောင်း/ကုန်ဝယ်မှတ်တမ်းတွင် အသုံးပြုထားလျှင် ဖျက်မရနိုင်ပါ။`))return;
 try{await runQuery("DELETE FROM products WHERE id=?",[p.id]);show("ဖျက်ပြီးပါပြီ။");await load();}catch(e){show("မှတ်တမ်းချိတ်ဆက်ထားသောကြောင့် ဖျက်မရပါ။",true);}
}
form.addEventListener("submit",async e=>{
 e.preventDefault();
 try{
  const v=values(), id=$("product-id").value;
  const params=[v.name,v.category,v.cost,v.retailPrice,v.qty,v.unit,v.min,v.packName,v.packSize,v.packCost,v.retail,v.wholesale,v.wholesalePrice,v.minQty];
  if(id) await runQuery(`UPDATE products SET name=?,category=?,purchase_price=?,selling_price=?,quantity=?,unit=?,min_stock=?,pack_name=?,pack_size=?,pack_purchase_price=?,retail_margin_pct=?,wholesale_margin_pct=?,wholesale_price=?,wholesale_min_qty=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`,[...params,Number(id)]);
  else await runQuery(`INSERT INTO products(name,category,purchase_price,selling_price,quantity,unit,min_stock,pack_name,pack_size,pack_purchase_price,retail_margin_pct,wholesale_margin_pct,wholesale_price,wholesale_min_qty) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,params);
  show(id?"ကုန်ပစ္စည်း ပြင်ဆင်ပြီးပါပြီ။":"ကုန်ပစ္စည်း အသစ်ထည့်ပြီးပါပြီ။");reset();await load();
 }catch(e){show(e.message||"သိမ်းဆည်းမရပါ။",true);}
});
["name","pack-size","pack-count","loose-quantity","pack-cost","retail-margin","wholesale-margin","wholesale-min"].forEach(id=>$(id).addEventListener("input",preview));
document.querySelectorAll("[data-retail]").forEach(b=>b.onclick=()=>{$("retail-margin").value=b.dataset.retail;preview();});
document.querySelectorAll("[data-wholesale]").forEach(b=>b.onclick=()=>{$("wholesale-margin").value=b.dataset.wholesale;preview();});
$("cancel-edit").onclick=reset;
$("search").addEventListener("input",e=>{const q=e.target.value.toLowerCase();render(products.filter(p=>(p.name||"").toLowerCase().includes(q)));});
(async()=>{try{await initDatabase();await load();preview();}catch(e){show("Database ချိတ်ဆက်မရပါ။ "+e.message,true);}})();
